import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const url = Deno.env.get('SUPABASE_URL')!;
const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || JSON.parse(Deno.env.get('SUPABASE_SECRET_KEYS') || '{}').default;
if (!serviceKey) throw new Error('Supabase secret key is not configured');

const admin = createClient(url, serviceKey, { auth: { autoRefreshToken: false, persistSession: false } });
const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Content-Type': 'application/json'
};
const json=(status:number,body:unknown)=>new Response(JSON.stringify(body),{status,headers:cors});
const clean=(v:unknown)=>String(v??'').trim();
const emailRe=/^[^\s@]+@[^\s@]+\.[^\s@]+$/;

async function provisionPaidFallback(args:{userId:string,email:string,name:string,organizationName:string,planCode:string,billing:any}) {
  // Compatibility path for production projects where the 6-argument RPC has not
  // been refreshed into PostgREST yet. This is idempotent and only handles paid plans.
  const {data:plan,error:planErr}=await admin.from('plans').select('*').eq('code',args.planCode).eq('active',true).maybeSingle();
  if(planErr) throw planErr;
  if(!plan) throw new Error(`Paid plan ${args.planCode} is not configured in the database. Apply the latest Supabase migrations and try again.`);

  const {error:profileErr}=await admin.from('profiles').upsert({
    user_id:args.userId,
    email:args.email,
    display_name:args.name||null,
    company_name:args.organizationName||null,
    updated_at:new Date().toISOString()
  },{onConflict:'user_id'});
  if(profileErr) throw profileErr;

  let {data:org,error:orgErr}=await admin.from('organizations').select('*').eq('status','active').order('created_at',{ascending:true});
  if(orgErr) throw orgErr;
  const orgIds=org||[];
  let targetOrg:any=null;
  for(const candidate of orgIds){
    const {data:membership}=await admin.from('organization_memberships').select('*').eq('organization_id',candidate.id).eq('user_id',args.userId).eq('status','active').maybeSingle();
    if(membership){ targetOrg=candidate; break; }
  }
  if(!targetOrg){
    const orgName=args.organizationName||`${args.email.split('@')[0]} Organization`;
    const slug=`${orgName.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'')||'organization'}-${crypto.randomUUID().replaceAll('-','').slice(0,8)}`;
    const createdOrg=await admin.from('organizations').insert({name:orgName,created_by:args.userId,slug}).select('*').single();
    if(createdOrg.error) throw createdOrg.error;
    targetOrg=createdOrg.data;
    const createdMembership=await admin.from('organization_memberships').insert({organization_id:targetOrg.id,user_id:args.userId,role:'owner',status:'active'}).select('*').single();
    if(createdMembership.error) throw createdMembership.error;
  }

  const existing=await admin.from('customer_orders').select('*').eq('organization_id',targetOrg.id).eq('requested_by',args.userId).eq('plan_code',args.planCode).eq('status','pending').in('payment_status',['unpaid','pending']).order('created_at',{ascending:false}).limit(1).maybeSingle();
  if(existing.error) throw existing.error;
  let order:any=existing.data||null;
  let sub:any=null;
  if(order){
    const sr=await admin.from('subscriptions').select('*').eq('order_id',order.id).order('created_at',{ascending:false}).limit(1).maybeSingle();
    if(sr.error) throw sr.error;
    sub=sr.data||null;
    const upd=await admin.from('customer_orders').update({customer_email:args.email,amount_thb:order.amount_thb??plan.price_thb,payload:{...(order.payload||{}),billing:args.billing||{},source:'existing_order_resume'},updated_at:new Date().toISOString()}).eq('id',order.id).select('*').single();
    if(upd.error) throw upd.error;
    order=upd.data;
  }else{
    const orderNumber=`KID-${new Date().toISOString().replace(/[-:TZ.]/g,'').slice(0,14)}-${crypto.randomUUID().replaceAll('-','').slice(0,6).toUpperCase()}`;
    const created=await admin.from('customer_orders').insert({
      order_number:orderNumber,
      organization_id:targetOrg.id,
      requested_by:args.userId,
      plan_code:args.planCode,
      status:'pending',
      payment_status:'unpaid',
      amount_thb:plan.price_thb,
      customer_email:args.email,
      payload:{source:'customer_signup_fallback',billing:args.billing||{}}
    }).select('*').single();
    if(created.error) throw created.error;
    order=created.data;
    const createdSub=await admin.from('subscriptions').insert({organization_id:targetOrg.id,plan_code:args.planCode,order_id:order.id,status:'pending',starts_at:new Date().toISOString(),expires_at:null}).select('*').single();
    if(createdSub.error) throw createdSub.error;
    sub=createdSub.data;
    const event=await admin.from('subscription_events').insert({subscription_id:sub.id,organization_id:targetOrg.id,order_id:order.id,event_type:'order_created',actor_user_id:args.userId,payload:{order_number:order.order_number,plan:args.planCode,source:'customer_signup_fallback'}});
    if(event.error) throw event.error;
  }
  if(!sub){
    const createdSub=await admin.from('subscriptions').insert({organization_id:targetOrg.id,plan_code:args.planCode,order_id:order.id,status:'pending',starts_at:new Date().toISOString(),expires_at:null}).select('*').single();
    if(createdSub.error) throw createdSub.error;
    sub=createdSub.data;
  }
  return {user_id:args.userId,organization:targetOrg,subscription:sub,plan,order,access_granted:false,message:'Account is ready; payment approval is required before workspace access'};
}


Deno.serve(async req=>{
  if(req.method==='OPTIONS') return new Response('ok',{headers:cors});
  if(req.method!=='POST') return json(405,{ok:false,error:'POST required'});
  try{
    const body=await req.json();
    const email=clean(body.email).toLowerCase();
    const password=clean(body.password);
    const name=clean(body.name);
    const organizationName=clean(body.organization_name);
    const plan=clean(body.plan || 'TRIAL_7');
    const billing=(body.billing && typeof body.billing==='object' && !Array.isArray(body.billing)) ? body.billing : null;

    if(!emailRe.test(email)) return json(400,{ok:false,error:'Valid email is required'});
    if(password.length<8) return json(400,{ok:false,error:'Password must be at least 8 characters'});
    if(!['TRIAL_7','PLAN_3M','PLAN_6M','PLAN_12M'].includes(plan)) return json(400,{ok:false,error:'Invalid plan'});
    let billingPayload:any=null;
    if(plan!=='TRIAL_7' && billing){
      const docs=Array.isArray(billing.documents)?billing.documents.map((x:any)=>clean(x).toUpperCase()).filter((x:string)=>['QUOTATION','TAX_INVOICE','RECEIPT'].includes(x)):[ ];
      const billingType=clean(billing.billingType).toUpperCase()==='JURISTIC'?'JURISTIC':'INDIVIDUAL';
      billingPayload={documents:[...new Set(docs)],billingType,legalName:clean(billing.legalName),taxId:clean(billing.taxId),branch:clean(billing.branch),phone:clean(billing.phone),address:clean(billing.address)};
      if(billingPayload.documents.length){
        if(!billingPayload.legalName||!billingPayload.phone||!billingPayload.address) return json(400,{ok:false,error:'Billing name, phone and address are required when billing documents are requested.'});
        if(billingType==='JURISTIC'&&(!billingPayload.taxId||!billingPayload.branch)) return json(400,{ok:false,error:'Juristic billing requires Tax ID and Branch.'});
      }
    }

    // Trial is deliberately limited to one redemption per email at the database layer.
    if(plan==='TRIAL_7'){
      const {data:used,error:usedErr}=await admin.from('trial_redemptions').select('id').eq('email',email).maybeSingle();
      if(usedErr) throw usedErr;
      if(used) return json(409,{ok:false,error:'This email has already used the KOL IDS free trial. Please sign in or choose a paid plan.'});
    }

    // Paid-plan upgrades may be started from an already-created account (for example
    // an expired 7-day trial). If the browser sends a valid Auth session, reuse that
    // identity instead of forcing the customer through a second signup.
    let user:any=null;
    const authHeader=req.headers.get('Authorization')||'';
    if(authHeader.startsWith('Bearer ')){
      const token=authHeader.slice(7).trim();
      if(token){
        const {data:authData,error:authErr}=await admin.auth.getUser(token);
        if(!authErr && authData?.user){
          const authEmail=clean(authData.user.email).toLowerCase();
          if(authEmail!==email) return json(403,{ok:false,error:'Signed-in account does not match the email on this order.'});
          user=authData.user;
        }
      }
    }

    if(!user){
      // Create the Auth identity server-side. Service/secret keys never reach the browser.
      const created=await admin.auth.admin.createUser({
        email,
        password,
        email_confirm:true,
        user_metadata:{name,company_name:organizationName,kol_ids_plan:plan}
      });
      if(created.error){
        const msg=created.error.message||'';
        if(/already|exists|registered/i.test(msg)) return json(409,{ok:false,code:'ACCOUNT_EXISTS',error:'An account with this email already exists. Sign in to continue with this plan.'});
        throw created.error;
      }
      user=created.data.user;
      if(!user) throw new Error('Account creation returned no user');
    }

    try{
      let provision:any=null;
      const rpc=await admin.rpc('provision_customer_account',{
        p_user_id:user.id,
        p_email:email,
        p_name:name,
        p_plan_code:plan,
        p_organization_name:organizationName || null,
        p_billing: billingPayload || {}
      });
      if(rpc.error){
        const msg=String(rpc.error.message||'');
        const rpcMissing=rpc.error.code==='PGRST202' || rpc.error.code==='42883' || /could not find the function|schema cache|does not exist/i.test(msg);
        if(plan!=='TRIAL_7' && rpcMissing){
          provision=await provisionPaidFallback({userId:user.id,email,name,organizationName,planCode:plan,billing:billingPayload||{}});
        }else{
          throw rpc.error;
        }
      }else{
        provision=rpc.data;
      }

      const order=provision?.order||null;

      // Return a one-time sign-in token only when explicitly requested by the caller.
      // The browser will normally sign in with the credentials it already holds.
      return json(200,{ok:true,user_id:user.id,plan,access_granted:Boolean(provision?.access_granted),message:provision?.message,order});
    }catch(err){
      // Compensating action only for a brand-new account. Never delete an existing customer's Auth identity.
      if(!authHeader.startsWith('Bearer ')){
        await admin.auth.admin.deleteUser(user.id);
      }
      throw err;
    }
  }catch(err){
    return json(500,{ok:false,error:err instanceof Error?err.message:'Account provisioning failed'});
  }
});
