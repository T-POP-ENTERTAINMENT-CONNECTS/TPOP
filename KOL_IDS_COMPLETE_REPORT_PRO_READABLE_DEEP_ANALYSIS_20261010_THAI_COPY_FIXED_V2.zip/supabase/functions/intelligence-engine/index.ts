import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const url = Deno.env.get('SUPABASE_URL')!;
const secretKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || JSON.parse(Deno.env.get('SUPABASE_SECRET_KEYS') || '{}').default;
if (!secretKey) throw new Error('Supabase secret key is not configured');
const admin = createClient(url, secretKey, {auth:{autoRefreshToken:false,persistSession:false}});
const MODEL='KOL_IDS_LEARNING_ENGINE_V3';
const CFG={PRIOR_STRENGTH:16,HALF_LIFE_DAYS:120,MIN_CREATOR_EVIDENCE:3,MIN_COHORT_EVIDENCE:5,MIN_INTERVAL_EVIDENCE:15,MIN_CALIBRATION_EVIDENCE:10,MIN_CREATOR_CALIBRATION:3,MIN_TRUST_EVIDENCE:25,SIMILARITY_FLOOR:.45,MAX_COHORT:60,MAX_CALIBRATION_ADJ:12,MAX_CREATOR_CAL_ADJ:10,MAX_DRIFT_ADJ:8};
const headers={'Content-Type':'application/json','Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization,content-type','Access-Control-Allow-Methods':'POST,OPTIONS'};
const json=(s:number,b:unknown)=>new Response(JSON.stringify(b),{status:s,headers});
const n=(v:any)=>v===''||v==null||!Number.isFinite(Number(v))?null:Number(v);
const clamp=(v:number,a=0,b=100)=>Math.max(a,Math.min(b,Number(v)||0));
const mean=(a:number[])=>a.length?a.reduce((s,v)=>s+v,0)/a.length:null;
const sd=(a:number[])=>{if(a.length<2)return a.length?0:null;const m=mean(a)!;return Math.sqrt(a.reduce((s,v)=>s+(v-m)**2,0)/(a.length-1));};
const q=(a:number[],p:number)=>{const x=a.filter(Number.isFinite).slice().sort((a,b)=>a-b);if(!x.length)return null;const i=(x.length-1)*p,j=Math.floor(i),f=i-j;return x[j]+(x[j+1]===undefined?0:(x[j+1]-x[j])*f)};
const recency=(date:string,asOf:string)=>Math.pow(.5,Math.max(0,(new Date(asOf).getTime()-new Date(date).getTime())/86400000)/CFG.HALF_LIFE_DAYS);
const performanceType=(o:any)=>{const t=String(o?.metadata?.channelType||'DIGITAL').toUpperCase();return t==='ECOMMERCE'||t==='OFFLINE'||t==='DIGITAL'?t:'DIGITAL'};
const tokens=(v:any)=>{const raw=String(v??'').toLowerCase();try{const seg=new Intl.Segmenter('th',{granularity:'word'});return Array.from(seg.segment(raw)).map((x:any)=>String(x.segment).trim()).filter((x:string)=>x.length>1&&/[\p{L}\p{N}]/u.test(x));}catch{return raw.split(/[,|;/\s]+/).map(x=>x.trim()).filter(Boolean)}};
function overlap(a:any,b:any){const A=new Set(tokens(a)),B=new Set(tokens(b));if(!A.size||!B.size)return 0;let hit=0;for(const x of A)if(B.has(x))hit++;return hit/Math.max(A.size,B.size)}
function similarity(a:any,b:any,goal:string){const pa=a?.payload||{},pb=b?.payload||{};const vals=[pa.channel&&pb.channel&&String(pa.channel).toLowerCase()===String(pb.channel).toLowerCase()?1:0,overlap(pa.intelligence?.content_function,pb.intelligence?.content_function),overlap(pa.intelligence?.audience_psychology,pb.intelligence?.audience_psychology),overlap(pa.intelligence?.audience_relationship,pb.intelligence?.audience_relationship),overlap(pa.intelligence?.social_behavior,pb.intelligence?.social_behavior)];const valid=vals.filter(x=>x!==null);return valid.length?valid.reduce((s,x)=>s+x,0)/valid.length:.0}
function validate(o:any){
 const errs:string[]=[],warnings:string[]=[];
 for(const k of ['spend_thb','revenue_thb','reach','impressions','views','likes','comments','shares','clicks','conversions','engagement']){
   const v=n(o[k]); if(v!==null&&v<0) errs.push('negative_'+k);
 }
 const type=performanceType(o), md=o.metadata||{};
 if(type==='ECOMMERCE'){
   for(const k of ['gmv','discounts','refunds','netSales','orders','paidOrders','newCustomers','commissionAmount']){
     const v=n(md[k]); if(v!==null&&v<0) errs.push('negative_'+k);
   }
   const cr=n(md.commissionRate); if(cr!==null&&(cr<0||cr>100)) errs.push('commission_rate_out_of_range');
   if(n(md.paidOrders)!=null&&n(md.orders)!=null&&n(md.paidOrders)>n(md.orders)) errs.push('paid_orders_gt_orders');
   if(n(md.netSales)!=null&&n(md.gmv)!=null&&n(md.netSales)>n(md.gmv)*1.01) warnings.push('net_sales_gt_gmv');
 }
 if(type==='OFFLINE'){
   for(const k of ['capacity','attendance','qualifiedLeads','qrScans','demos','samples']){
     const v=n(md[k]); if(v!==null&&v<0) errs.push('negative_'+k);
   }
   if(n(md.capacity)!=null&&n(md.attendance)!=null&&n(md.attendance)>n(md.capacity)) errs.push('attendance_gt_capacity');
 }
 const imp=n(o.impressions),clicks=n(o.clicks),conv=n(o.conversions),eng=n(o.engagement);
 if(imp!=null&&clicks!=null&&clicks>imp*1.02) warnings.push('clicks_gt_impressions');
 if(clicks!=null&&conv!=null&&conv>clicks*1.02) warnings.push('conversions_gt_clicks');
 if(eng!=null){const minEng=(n(o.likes)||0)+(n(o.comments)||0)+(n(o.shares)||0);if(eng+0.5<minEng)warnings.push('engagement_below_components');}
 const present=['reach','impressions','views','likes','comments','shares','clicks','conversions','engagement'].map(k=>n(o[k])).filter(v=>v!==null).length;
 let quality=o.source==='VERIFIED'||o.source==='API'?1:o.source==='SELF-REPORTED'?.72:o.source==='ESTIMATED'?.45:.60;
 quality*=Math.min(1,.50+present*.055);
 if(warnings.length)quality*=Math.max(.72,1-warnings.length*.06);
 return {ok:!errs.length,errors:errs,warnings,quality:clamp(quality*100,25,100)}
}
function outcome(o:any,goal:string){
 const type=performanceType(o), imp=n(o.impressions),views=n(o.views),eng=n(o.engagement)??((n(o.likes)||0)+(n(o.comments)||0)+(n(o.shares)||0)),clicks=n(o.clicks),conv=n(o.conversions),rev=n(o.revenue_thb),spend=n(o.spend_thb);
 const norm=(v:number|null,cap:number)=>v==null?null:clamp(v/cap*100); const g=String(goal||'AWARENESS').toUpperCase();
 if(type==='ECOMMERCE'){
   const gmv=n(o.metadata?.gmv)??rev, net=n(o.metadata?.netSales)??rev, orders=n(o.metadata?.paidOrders)??conv, newCustomers=n(o.metadata?.newCustomers), commission=n(o.metadata?.commissionAmount),
         roas=spend&&net!=null?net/spend:null, cvr=clicks&&orders!=null?orders/clicks*100:null, takeRate=gmv&&net!=null?net/gmv*100:null;
   let parts:any[][];
   if(/SALES|CONVERSION|REVENUE/.test(g)) parts=[[norm(roas,6),.40],[norm(net,500000),.25],[norm(cvr,8),.15],[norm(newCustomers,300),.10],[norm(orders,500),.10]];
   else if(/ENGAGEMENT|CONSIDERATION/.test(g)) parts=[[norm(orders,500),.30],[norm(net,500000),.25],[norm(cvr,8),.20],[norm(takeRate,100),.10],[norm(gmv,600000),.15]];
   else parts=[[norm(gmv,600000),.30],[norm(net,500000),.30],[norm(orders,500),.20],[norm(newCustomers,300),.10],[norm(takeRate,100),.10]];
   const v=parts.filter(x=>x[0]!==null),tw=v.reduce((s,x)=>s+x[1],0); return tw?v.reduce((s,x)=>s+x[0]*x[1],0)/tw:null;
 }
 if(type==='OFFLINE'){
   const cap=n(o.metadata?.capacity),attendance=n(o.metadata?.attendance),leads=n(o.metadata?.qualifiedLeads),scans=n(o.metadata?.qrScans),demos=n(o.metadata?.demos),
         leadRate=attendance&&leads!=null?leads/attendance*100:null,convRate=attendance&&conv!=null?conv/attendance*100:null,scanRate=attendance&&scans!=null?scans/attendance*100:null,demoRate=attendance&&demos!=null?demos/attendance*100:null,roas=spend&&rev!=null?rev/spend:null,attRate=cap&&attendance!=null?attendance/cap*100:null;
   const g2=String(goal||'AWARENESS').toUpperCase(); let parts:any[][]=[];
   if(/CONVERSION|SALES/.test(g2)) parts=[[norm(roas,6),.40],[norm(convRate,10),.20],[norm(leadRate,25),.15],[norm(rev,500000),.15],[norm(demoRate,15),.10]];
   else if(/ENGAGEMENT|COMMUNITY/.test(g2)) parts=[[norm(leadRate,20),.30],[norm(demoRate,15),.25],[norm(scanRate,30),.20],[norm(attRate,100),.25]];
   else parts=[[norm(attRate,100),.30],[norm(leads,500),.25],[norm(demos,300),.15],[norm(scans,500),.15],[norm(rev,500000),.15]];
   const v=parts.filter(x=>x[0]!==null),tw=v.reduce((s,x)=>s+x[1],0);return tw?v.reduce((s,x)=>s+x[0]*x[1],0)/tw:null;
 }
 const er=imp&&eng!=null?eng/imp*100: null,ctr=imp&&clicks!=null?clicks/imp*100:null,cvr=clicks&&conv!=null?conv/clicks*100:null,roas=spend&&rev!=null?rev/spend:null;
 let p:any[][];
 if(/CONVERSION|SALES/.test(g))p=[[norm(roas,6),.40],[norm(cvr,8),.25],[norm(ctr,5),.15],[norm(rev,500000),.20]];
 else if(g.includes('ENGAGEMENT'))p=[[norm(er,8),.65],[norm(views,2000000),.15],[norm(eng,100000),.20]];
 else if(g.includes('CONSIDERATION'))p=[[norm(ctr,5),.40],[norm(er,8),.35],[norm(cvr,8),.25]];
 else if(g.includes('LAUNCH'))p=[[norm(n(o.reach),2000000),.45],[norm(views,2000000),.25],[norm(er,8),.20],[norm(ctr,5),.10]];
 else p=[[norm(n(o.reach),2000000),.55],[norm(views,2000000),.20],[norm(er,8),.25]];
 const v=p.filter(x=>x[0]!==null),tw=v.reduce((s,x)=>s+x[1],0);return tw?v.reduce((s,x)=>s+x[0]*x[1],0)/tw:null
}
async function member(userId:string,orgId:string){const {data}=await admin.from('organization_memberships').select('organization_id,role,status').eq('organization_id',orgId).eq('user_id',userId).eq('status','active').maybeSingle();return !!data}
async function activeAccess(orgId:string){const {data,error}=await admin.from('subscriptions').select('plan_code,status,starts_at,expires_at').eq('organization_id',orgId).eq('status','active').order('expires_at',{ascending:false,nullsFirst:false}).limit(10);if(error)throw error;const now=Date.now();return (data||[]).some((x:any)=>new Date(String(x.starts_at||0)).getTime()<=now&&(!x.expires_at||new Date(String(x.expires_at)).getTime()>now));}
async function auth(req:Request){const h=req.headers.get('authorization')||'';const token=h.replace(/^Bearer\s+/i,'');if(!token)throw new Error('Authorization required');const {data,error}=await admin.auth.getUser(token);if(error||!data.user)throw new Error('Unauthorized');return data.user}
async function rows(orgId:string,creatorId?:string,asOf?:string){let qy=admin.from('performance_observations').select('*').eq('organization_id',orgId).eq('status','COMPLETED').order('observed_at',{ascending:false});if(creatorId)qy=qy.eq('creator_id',creatorId);if(asOf)qy=qy.lte('observed_at',asOf);const {data,error}=await qy; if(error)throw error;return data||[]}
async function calibration(orgId:string,goal:string,asOf:string,excludeCampaignId?:string){let qy=admin.from('prediction_ledger').select('*').eq('organization_id',orgId).eq('goal',goal).not('actual_score','is',null).lte('actual_at',asOf).order('actual_at',{ascending:false});const {data,error}=await qy;if(error)throw error;const a=(data||[]).filter(x=>!excludeCampaignId||x.campaign_id!==excludeCampaignId);if(!a.length)return {bias:0,mae:null,n:0,effectiveN:0,coverage80:null};let sw=0,b=0,mae=0;for(const x of a){const w=recency(x.actual_at,asOf);sw+=w;b+=w*(Number(x.actual_score)-Number(x.predicted_score));mae+=w*Math.abs(Number(x.actual_score)-Number(x.predicted_score))}return {bias:b/sw,mae:mae/sw,n:a.length,effectiveN:sw,coverage80:a.length>=CFG.MIN_INTERVAL_EVIDENCE?mean(a.map(x=>x.covered?1:0)):null}}
async function predict(orgId:string,creator:any,goal:string,excludeCampaignId:string,asOf:string){const own=(await rows(orgId,creator.id,asOf)).filter(x=>x.campaign_id!==excludeCampaignId&&String(x.goal||'').toUpperCase()===String(goal).toUpperCase()).map(x=>({...x,score:outcome(x,goal),quality:n(x.quality_score)??validate(x).quality})).filter(x=>x.score!==null);const all=await rows(orgId,undefined,asOf);const seen=new Set<string>();const cohort:any[]=[];for(const x of all){if(x.creator_id===creator.id||x.campaign_id===excludeCampaignId||seen.has(x.id)||String(x.goal||'').toUpperCase()!==String(goal).toUpperCase())continue;const otherCreatorCache:any=await admin.from('creators').select('*').eq('id',x.creator_id).eq('organization_id',orgId).maybeSingle();const other=otherCreatorCache.data;if(!other)continue;const sim=similarity(creator,other,goal);if(sim<CFG.SIMILARITY_FLOOR)continue;const score=outcome(x,goal);if(score===null)continue;seen.add(x.id);cohort.push({...x,score,similarity:sim,quality:n(x.quality_score)??validate(x).quality})}cohort.sort((a,b)=>(b.similarity*b.quality)-(a.similarity*a.quality));cohort.splice(CFG.MAX_COHORT);const om=weighted(own.map(x=>({v:x.score,w:recency(x.observed_at,asOf)*(x.quality/100)})));const cm=weighted(cohort.map(x=>({v:x.score,w:recency(x.observed_at,asOf)*(x.quality/100)*x.similarity*x.similarity})));const ownN=own.length,cohortN=cohort.length,ownMean=om?.mean??null,cohortMean=cm?.mean??null;const ownTrust=ownN/(ownN+6);const pooled=ownMean!==null&&cohortMean!==null?ownMean*ownTrust+cohortMean*(1-ownTrust):(ownMean??cohortMean??50);const totalW=(om?.weight||0)+(cm?.weight||0)*.65;const shrink=totalW/(totalW+CFG.PRIOR_STRENGTH);const score=clamp(50+(pooled-50)*shrink);const ev=[...own,...cohort].map(x=>x.score);return {score,ownN,cohortN,effectiveN:totalW,dispersion:sd(ev)??18,freshness:mean([...own,...cohort].map(x=>recency(x.observed_at,asOf)))??0,status:ownN>=CFG.MIN_CREATOR_EVIDENCE?'CREATOR_EVIDENCE':cohortN>=CFG.MIN_COHORT_EVIDENCE?'COHORT_EVIDENCE':'PRIOR_SHRUNK',cohort:cohort.slice(0,10).map(x=>({creatorId:x.creator_id,campaignId:x.campaign_id,similarity:x.similarity,quality:x.quality,score:x.score})),platformPerformance:platformPerformanceSummary(own,goal)}}
function weighted(items:any[]){let sw=0,sv=0;for(const x of items){if(Number.isFinite(x.v)&&x.w>0){sw+=x.w;sv+=x.w*x.v}}return sw?{mean:sv/sw,weight:sw}:null}
function platformPerformanceSummary(rows:any[],goal:string){
 const by=new Map<string,any[]>();for(const x of rows){const p=String(x.metadata?.platform||x.metadata?.channel||'UNSPECIFIED').toLowerCase();if(!by.has(p))by.set(p,[]);by.get(p)!.push(x)}
 const platforms=[...by.entries()].map(([platform,items])=>{const scores=items.map(x=>outcome(x,goal)).filter((v:any)=>v!=null);const spend=items.reduce((s,x)=>s+(Number(x.spend_thb)||0),0),revenue=items.reduce((s,x)=>s+(Number(x.revenue_thb)||0),0),reach=items.reduce((s,x)=>s+(Number(x.reach)||0),0),views=items.reduce((s,x)=>s+(Number(x.views)||0),0),clicks=items.reduce((s,x)=>s+(Number(x.clicks)||0),0),conversions=items.reduce((s,x)=>s+(Number(x.conversions)||0),0);return {platform,records:items.length,performanceScore:scores.length?mean(scores):null,spend,revenue,observedReach:reach,observedViews:views,clicks,conversions,roas:spend?revenue/spend:null}});
 const scores=platforms.map(x=>x.performanceScore).filter((v:any)=>v!=null);return {platforms,platformCount:platforms.length,blendedPerformance:scores.length?mean(scores):null,note:'Cross-platform reach/views are observed platform totals and are not deduplicated unique-user reach.'};
}
async function drift(orgId:string,creatorId:string,goal:string,asOf:string){const h=(await rows(orgId,creatorId,asOf)).filter(x=>String(x.goal||'').toUpperCase()===String(goal).toUpperCase()).map(x=>outcome(x,goal)).filter(v=>v!==null) as number[];if(h.length<8)return {delta:0,status:'INSUFFICIENT_DATA',n:h.length};const m=Math.floor(h.length/2),old=mean(h.slice(m)),recent=mean(h.slice(0,m)),delta=recent!-old!;return {delta,status:Math.abs(delta)>=10?'DRIFT_DETECTED':'STABLE',n:h.length}}
async function interval(orgId:string,goal:string,asOf:string,excludeCampaignId:string,center:number){let qy=admin.from('prediction_ledger').select('*').eq('organization_id',orgId).eq('goal',goal).not('actual_score','is',null).not('predicted_score','is',null).lte('actual_at',asOf);const {data,error}=await qy;if(error)throw error;const res=(data||[]).filter(x=>x.campaign_id!==excludeCampaignId).map(x=>Number(x.actual_score)-Number(x.predicted_score));if(res.length<CFG.MIN_INTERVAL_EVIDENCE)return {lower:clamp(center-20),upper:clamp(center+20),n:res.length,coverage80:null,method:'WIDE_PRIOR'};return {lower:clamp(center+(q(res,.1)||0)),upper:clamp(center+(q(res,.9)||0)),q05:q(res,.05),q95:q(res,.95),n:res.length,coverage80:mean((data||[]).filter(x=>x.campaign_id!==excludeCampaignId&&x.covered!=null).map(x=>x.covered?1:0)),method:'OOS_RESIDUALS'}}
async function creatorCalibration(orgId:string,creatorId:string,goal:string,asOf:string,excludeCampaignId?:string){
 let qy=admin.from('prediction_ledger').select('actual_score,predicted_score,actual_at,campaign_id').eq('organization_id',orgId).eq('creator_id',creatorId).eq('goal',goal).not('actual_score','is',null).not('predicted_score','is',null).lte('actual_at',asOf).order('actual_at',{ascending:false});
 const {data,error}=await qy;if(error)throw error;const a=(data||[]).filter(x=>!excludeCampaignId||x.campaign_id!==excludeCampaignId);if(!a.length)return {bias:0,mae:null,n:0,effectiveN:0};
 let sw=0,b=0,mae=0;for(const x of a){const w=recency(x.actual_at,asOf);sw+=w;b+=w*(Number(x.actual_score)-Number(x.predicted_score));mae+=w*Math.abs(Number(x.actual_score)-Number(x.predicted_score))}
 return {bias:b/sw,mae:mae/sw,n:a.length,effectiveN:sw};
}
async function signal(orgId:string,creator:any,goal:string,campaignId:string,asOf:string){
 const p=await predict(orgId,creator,goal,campaignId,asOf),cal=await calibration(orgId,goal,asOf,campaignId),creatorCal=await creatorCalibration(orgId,creator.id,goal,asOf,campaignId),dr=await drift(orgId,creator.id,goal,asOf);
 const calAdj=cal.n>=CFG.MIN_CALIBRATION_EVIDENCE?clamp(cal.bias*.30,-CFG.MAX_CALIBRATION_ADJ,CFG.MAX_CALIBRATION_ADJ):0;
 const creatorCalAdj=creatorCal.n>=CFG.MIN_CREATOR_CALIBRATION?clamp(creatorCal.bias*.35,-CFG.MAX_CREATOR_CAL_ADJ,CFG.MAX_CREATOR_CAL_ADJ):0;
 const driftAdj=dr.n>=8?clamp(dr.delta*.06,-CFG.MAX_DRIFT_ADJ,CFG.MAX_DRIFT_ADJ):0;
 const corrected=clamp(p.score+calAdj+creatorCalAdj+driftAdj);
 const intv=await interval(orgId,goal,asOf,campaignId,corrected);
 let conf=20+Math.min(35,p.effectiveN*4)+Math.min(15,p.ownN*3)+Math.min(10,p.cohortN*.5)+Math.min(8,p.freshness*8);
 if(p.dispersion>18)conf-=10;else if(p.dispersion>12)conf-=5;
 if(cal.n>=CFG.MIN_CALIBRATION_EVIDENCE)conf+=8;else conf-=8;
 if(creatorCal.n>=CFG.MIN_CREATOR_CALIBRATION)conf+=Math.min(8,creatorCal.n*1.5);
 if(intv.method!=='OOS_RESIDUALS')conf-=12;if(dr.status==='DRIFT_DETECTED')conf-=12;if(intv.coverage80!=null&&intv.coverage80<.70)conf-=6;
 conf=Math.round(clamp(conf,5,97));
 const guard=cal.n>=CFG.MIN_CALIBRATION_EVIDENCE?'CALIBRATED':'INSUFFICIENT_CALIBRATION_EVIDENCE';
 const trust=guard==='CALIBRATED'&&cal.n>=CFG.MIN_TRUST_EVIDENCE&&intv.method==='OOS_RESIDUALS'&&p.ownN>=CFG.MIN_CREATOR_EVIDENCE?'HIGH':guard==='CALIBRATED'?'MEDIUM':'LOW';
 return {...p,score:corrected,lower:intv.lower,upper:intv.upper,confidence:conf,calibrationBias:cal.bias,calibrationMAE:cal.mae,calibrationN:cal.n,effectiveCalibrationN:cal.effectiveN,creatorCalibrationBias:creatorCal.bias,creatorCalibrationMAE:creatorCal.mae,creatorCalibrationN:creatorCal.n,effectiveCreatorCalibrationN:creatorCal.effectiveN,intervalCoverage80:intv.coverage80,intervalMethod:intv.method,drift:driftAdj,driftStatus:dr.status,modelTrust:trust,modelVersion:MODEL,calibrationStatus:guard,learningState:creatorCal.n>=CFG.MIN_CREATOR_CALIBRATION?'ADAPTED_TO_CREATOR_HISTORY':cal.n>=CFG.MIN_CALIBRATION_EVIDENCE?'ADAPTED_TO_ACCOUNT_HISTORY':'PRIOR_ONLY',accuracyGuard:'STRICT_TIME + NO LEAKAGE + DATA_QUALITY + CREATOR_CALIBRATION + SHRINKAGE + OOS_CALIBRATION + DRIFT_GUARD + SPARSE_DATA_GUARD'}
}

function textBlob(v:any){if(Array.isArray(v))return v.join(' ').toLowerCase();return String(v??'').toLowerCase()}
function fitOverlap(creatorVals:any,audienceText:any){const A=new Set(tokens(creatorVals));const B=new Set(tokens(audienceText));if(!A.size||!B.size)return 0;let hit=0;for(const x of A)if(B.has(x))hit++;return clamp(hit/Math.max(1,Math.min(A.size,6))*100)}
function matchingTokens(creatorVals:any,targetText:any){const A=[...new Set(tokens(creatorVals))],B=new Set(tokens(targetText));return A.filter(x=>B.has(x)).slice(0,6)}
function dimensionEvidence(label:string,score:number,creatorVals:any,targetText:any,lowAction:string){const matches=matchingTokens(creatorVals,targetText);const signalText=Array.isArray(creatorVals)?creatorVals.filter(Boolean).join(', '):String(creatorVals||'');if(matches.length)return {score,matchedSignals:matches,reason:`${label} ${score}/100. Matching evidence: ${matches.join(', ')}. Creator signals recorded: ${signalText||'·'}.`,action:score<70?lowAction:'Maintain the current creator-native approach and keep the brief aligned to the campaign.'};return {score,matchedSignals:[],reason:`${label} ${score}/100. No direct text-level signal overlap was found between the stored creator signals (${signalText||'·'}) and the current campaign context. The score is therefore evidence-limited rather than a claim of incompatibility.`,action:score<70?lowAction:'Keep the brief explicit so the fit can be validated with campaign evidence.'}}
function calculatedFits(creator:any,campaign:any,audience:any,historical:any,commercial:number){
 const cp=creator?.payload||{},bp=campaign?.payload||{},ap=audience?.payload||{},ci=cp.intelligence||{};
 const audienceText=[ap.audienceType,ap.age,ap.painPoints,ap.lifestyle,ap.whyBrand,ap.behavior,ap.market,ap.interests,ap.income,ap.purchaseContext,ap.audiencePersona].join(' ');
 const brandText=[bp.brandPositioning,bp.brandPromise,bp.brandValuesText,bp.brandPersonalities,bp.keyMessages].join(' ');
 const objectiveText=[bp.objective,bp.objectives,bp.goal,bp.keyMessages].join(' ');
 const audienceFit=clamp(Math.round((fitOverlap(ci.Audience_Psychology,audienceText)*.45+fitOverlap(ci.Audience_Relationship,audienceText)*.35+fitOverlap(ci.Social_Behavior,audienceText)*.20)||50));
 const contentFit=clamp(Math.round((fitOverlap(ci.Content_Function,objectiveText)*.45+fitOverlap(ci.Content_Personality,objectiveText)*.30+fitOverlap(ci.Content_Behavior,objectiveText)*.25)||50));
 const brandFit=clamp(Math.round((fitOverlap(ci.Personality,brandText)*.35+fitOverlap(ci.Communication,brandText)*.25+fitOverlap(ci.Content_Personality,brandText)*.25+fitOverlap(ci.Content_Function,objectiveText)*.15)||50));
 const avoid=textBlob(bp.brandAvoidText),creatorText=textBlob(Object.values(ci));
 const avoidHits=tokens(avoid).filter(x=>x.length>2&&creatorText.includes(x)).length;
 const risk=clamp(Math.round(20+Math.min(55,avoidHits*15)+(cp.profileUrl?0:5)));
 const hasPerformance=Number(historical?.effectiveN||0)>0 || Number(historical?.ownN||0)>0 || Number(historical?.cohortN||0)>0;
 const performance=hasPerformance?clamp(Math.round(Number(historical.score??50))):null;
 const audienceEvidence=dimensionEvidence('Audience Fit',audienceFit,[...(ci.Audience_Psychology||[]),...(ci.Audience_Relationship||[]),...(ci.Social_Behavior||[])],audienceText,'Align the creator to the defined audience persona: use audience-specific topics, language and community behavior instead of changing the creator identity. Validate audience response with a controlled test.');
 const contentEvidence=dimensionEvidence('Campaign / Objective Fit',contentFit,[...(ci.Content_Function||[]),...(ci.Content_Personality||[]),...(ci.Content_Behavior||[])],objectiveText,"Change the execution, not the creator identity: use a format and CTA that directly serve the campaign objective and preserve the creator's native style.");
 const brandEvidence=dimensionEvidence('Brand Fit',brandFit,[...(ci.Personality||[]),...(ci.Communication||[]),...(ci.Content_Personality||[])],brandText,'Give the creator a tighter brand brief covering tone, key message, proof points and must-avoid topics, with pre-approval for the first content asset.');
 const performanceScore=performance??50;
 const performanceEvidence={score:performanceScore,available:hasPerformance,reason:hasPerformance?`Observed performance prediction ${performanceScore}/100. Based on ${historical.ownN||0} creator-specific outcome record(s), ${historical.cohortN||0} comparable cohort record(s), confidence ${Math.round(historical.confidence||0)}/100 and model trust ${historical.modelTrust||'LOW'}.`:`Performance evidence is unavailable. The engine does not treat missing history as poor performance; the performance component is held neutral at 50/100 until evidence is observed.`,action:!hasPerformance?'Run a controlled first activation with one primary KPI and record verified outcome evidence before scaling.':performanceScore<70?'Use a lower-risk test brief and feed the observed result back into creator evidence.':'Keep the creator-native execution and continue collecting campaign-specific outcome evidence.'};
 const commercialEvidence={score:commercial,reason:commercial===50?`Commercial fit ${commercial}/100. Creator fee or campaign budget is missing, so fee efficiency cannot be strongly evaluated.`:`Commercial fit ${commercial}/100. Calculated from creator fee ${cp.rate==null?'not provided':Number(cp.rate)} against campaign budget ${campaign.payload?.budget==null?'not provided':Number(campaign.payload.budget)}.`,action:commercial<70?'Renegotiate scope/fee, reduce deliverables, or use a smaller pilot so the activation stays efficient against the campaign budget.':'Keep the agreed scope aligned to the fee and campaign budget; avoid adding unpaid deliverables.'};
 const riskReason=avoidHits?`Risk ${risk}/100. ${avoidHits} stored creator signal(s) overlap with the brand avoid list; tighten guardrails before publishing.`:`Risk ${risk}/100. No direct overlap with the stored brand avoid list was detected; this is a content-governance signal, not a guarantee of zero risk.`;
 const gaps=[['Audience',audienceFit],['Campaign / Objective',contentFit],['Brand',brandFit]].sort((a,b)=>Number(a[1])-Number(b[1]));
 const recovery=[];
 if(Number(gaps[0][1])<70)recovery.push({priority:1,area:gaps[0][0],action:gaps[0][0]==='Audience'?audienceEvidence.action:gaps[0][0]==='Brand'?brandEvidence.action:contentEvidence.action});
 if(Number(gaps[1][1])<70)recovery.push({priority:2,area:gaps[1][0],action:gaps[1][0]==='Audience'?audienceEvidence.action:gaps[1][0]==='Brand'?brandEvidence.action:contentEvidence.action});
 if(!hasPerformance||performanceScore<70)recovery.push({priority:3,area:'Performance Evidence',action:performanceEvidence.action});
 if(commercial<70)recovery.push({priority:4,area:'Commercial Fit',action:commercialEvidence.action});
 if(risk>50)recovery.push({priority:3,area:'Risk / Guardrails',action:'Add content review, usage boundaries and a clear must-avoid list before launch.'});
 if(!recovery.length)recovery.push({priority:1,area:'Optimization',action:'Keep the creator-native execution, make the KPI and key message explicit, and validate performance with campaign evidence.'});
 return{audienceFit,contentFit,brandFit,performance,risk,performanceEvidenceAvailable:hasPerformance,reason:`Calculated from campaign objective, brand context and guardrails, audience persona, creator intelligence signals and available historical evidence. ${historical.ownN||0} creator-specific outcome records and ${historical.cohortN||0} comparable cohort records were available.`,dimensionEvidence:{audience:audienceEvidence,campaign:contentEvidence,brand:brandEvidence,performance:performanceEvidence,commercial:commercialEvidence,risk:{score:risk,reason:riskReason,action:risk>50?'Add content review, usage boundaries and a clear must-avoid list before launch.':'Keep the current guardrails and re-check after any brief or creator-positioning change.'}},recoveryPlan:recovery,lowestFit:{area:String(gaps[0][0]),score:Number(gaps[0][1])}}
}
async function runAnalysis(orgId:string,campaign:any,audience:any,creators:any[],userId:string){
 const goal=String(campaign.payload?.objective||'AWARENESS').toUpperCase(),asOf=new Date().toISOString(),out:any[]=[];
 const weights=campaign.payload?.decisionWeights||{brand:20,audience:20,campaign:15,confidence:15,value:15,risk:15};
 const total=Object.values(weights as Record<string,any>).reduce((s:number,v:any)=>s+Number(v||0),0);
 if(Math.round(total)!==100)throw new Error('Decision weights must total exactly 100%');
 if(creators.length>100)throw new Error('A maximum of 100 creators can be analyzed per run.');
 for(const cr of creators){
   const s=await signal(orgId,cr,goal,campaign.id,asOf),p=cr.payload||{};
   const commercial=campaign.payload?.budget>0&&n(p.rate)!=null?clamp(100-(Number(p.rate)/Number(campaign.payload.budget))*100):50;
   const fits=calculatedFits(cr,campaign,audience,s,commercial);
   const performanceComponent=clamp(50+(Number(s.score||50)-50)*(0.55+0.45*(Number(s.confidence||0)/100)));
   const rawScore=clamp(fits.brandFit*(Number(weights.brand)/100)+fits.audienceFit*(Number(weights.audience)/100)+fits.contentFit*(Number(weights.campaign)/100)+performanceComponent*(Number(weights.confidence)/100)+commercial*(Number(weights.value)/100)+(100-fits.risk)*(Number(weights.risk)/100));
   const reliability=0.70+0.30*(Number(s.confidence||0)/100);
   const score=clamp(50+(rawScore-50)*reliability);
   const threshold=n(campaign.payload?.threshold)??70,ceiling=n(campaign.payload?.riskCeiling)??60;
   let decision='NOT RECOMMENDED';
   const noHistory=!fits.performanceEvidenceAvailable&&s.modelTrust==='LOW';
   if(noHistory)decision='INSUFFICIENT HISTORICAL EVIDENCE';
   else if(fits.risk>ceiling)decision='RISK EXCEEDS CEILING';
   else if(score>=threshold&&s.confidence>=60)decision='RECOMMENDED';
   else if(score>=60)decision='CONSIDER';
   const evidence={...s,...fits,commercial,performanceComponent,rawScore,decisionScore:score,confidence:s.confidence,confidenceDefinition:'Confidence measures evidence reliability and model uncertainty; it is not added as a positive fit component. Low confidence shrinks performance influence toward neutral.',learning:{state:s.learningState,creatorCalibrationN:s.creatorCalibrationN,creatorCalibrationBias:s.creatorCalibrationBias,accountCalibrationN:s.calibrationN,accountCalibrationBias:s.calibrationBias,driftStatus:s.driftStatus},method:'V3: fit dimensions + calibrated performance prediction + commercial efficiency − risk. Performance is reliability-shrunk toward neutral when evidence confidence is low; missing history never becomes a negative performance score.',threshold,ceiling,creatorEvidence:s.ownN,cohortEvidence:s.cohortN,modelGovernance:{modelVersion:MODEL,asOf,strictNoLeakage:true,performanceEvidenceAvailable:fits.performanceEvidenceAvailable,intervalMethod:s.intervalMethod,calibrationStatus:s.calibrationStatus,driftStatus:s.driftStatus}};
   const ins=await admin.from('creator_decisions').insert({organization_id:orgId,campaign_id:campaign.id,creator_id:cr.id,decision,score,evidence,created_by:userId}).select().single();if(ins.error)throw ins.error;
   const pred=await admin.from('prediction_ledger').insert({organization_id:orgId,campaign_id:campaign.id,creator_id:cr.id,goal,predicted_at:asOf,predicted_score:s.score,lower_bound:s.lower,upper_bound:s.upper,model_version:MODEL,method:s.intervalMethod,evidence:{confidence:s.confidence,ownN:s.ownN,cohortN:s.cohortN,calibrationN:s.calibrationN,creatorCalibrationN:s.creatorCalibrationN,drift:s.driftStatus,learningState:s.learningState,decisionScore:score,performanceComponent,modelGovernance:evidence.modelGovernance}});if(pred.error)throw pred.error;
   out.push(ins.data);
 }
 const run=await admin.from('intelligence_runs').insert({organization_id:orgId,campaign_id:campaign.id,run_type:'DECISION_ENGINE',model_version:MODEL,status:'COMPLETED',parameters:{weights,threshold:n(campaign.payload?.threshold)??70,riskCeiling:n(campaign.payload?.riskCeiling)??60,asOf,creatorCount:creators.length,governance:'V3 reliability-shrunk performance, missing-evidence neutral, OOS calibration, no-leakage'} ,result:{count:out.length,records:out.map(x=>x.id)},created_by:userId}).select().single();if(run.error)throw run.error;
 return {success:true,modelVersion:MODEL,goal,asOf,rows:out,runId:run.data.id}
}
async function portfolio(orgId:string,campaign:any,creators:any[],userId:string){const decisions=(await admin.from('creator_decisions').select('*').eq('organization_id',orgId).eq('campaign_id',campaign.id).order('created_at',{ascending:false})).data||[];const latest=new Map<string,any>();for(const d of decisions)if(d.creator_id&&!latest.has(d.creator_id))latest.set(d.creator_id,d);const budget=Number(campaign.payload?.budget||0),ceiling=Number(campaign.payload?.riskCeiling??60),objective=String(campaign.payload?.objective||'AWARENESS');const cand=creators.map(c=>{const d=latest.get(c.id);const p=c.payload||{};const cost=Number(p.rate||0);const ev=d?.evidence||{};const risk=Number(ev.risk??p.risk??50);const conf=Number(ev.confidence??5);const score=Number(d?.score??0);const alignment=clamp((Number(ev.brandFit??p.brand??50)+Number(ev.audienceFit??p.audience??50)+Number(ev.contentFit??p.content??50))/3);const base=clamp(score*.70+alignment*.30);const reliability=.70+.30*(conf/100);const value=clamp(50+(base-50)*reliability);return {creator:c,d, cost,risk,confidence:conf,candidateScore:value,objectiveAlignment:alignment,impact:score,evidenceScore:conf}}).filter(x=>x.d&&!String(x.d.decision||'').includes('INSUFFICIENT')&&x.risk<=ceiling&&x.cost<=budget).sort((a,b)=>b.candidateScore-a.candidateScore);let spend=0,selected:any[]=[];for(const x of cand){if(spend+x.cost>budget)continue;selected.push(x);spend+=x.cost}const avgSel=mean(selected.map(x=>x.candidateScore))||0,coverage=cand.length?selected.length/cand.length*100:0,riskExp=selected.length?selected.reduce((s,x)=>s+x.risk,0)/selected.length:0,conf=selected.length?selected.reduce((s,x)=>s+x.confidence,0)/selected.length:0,synergy=selected.length>1?clamp(100-mean(selected.map(x=>Math.abs(x.objectiveAlignment-avgSel)))!):selected.length?50:0;const pr=await admin.from('portfolio_runs').insert({organization_id:orgId,campaign_id:campaign.id,budget_thb:budget,status:selected.length?'OPTIMIZED':'NO_FEASIBLE_PORTFOLIO',portfolio_score:avgSel,confidence:conf,planned_spend:spend,budget_remaining:budget-spend,risk_exposure:riskExp,coverage_score:coverage,synergy_score:synergy,objective,result:{objective,selectedCount:selected.length,totalCandidates:cand.length},created_by:userId}).select().single();if(pr.error)throw pr.error;for(let i=0;i<selected.length;i++){const x=selected[i];await admin.from('portfolio_items').insert({portfolio_run_id:pr.data.id,creator_id:x.creator.id,rank:i+1,allocation_thb:x.cost,candidate_score:x.candidateScore,objective_alignment:x.objectiveAlignment,impact_score:x.impact,confidence:x.confidence,risk:x.risk,evidence_score:x.evidenceScore,selection_reason:'Greedy constrained portfolio: highest evidence-aware candidate score within budget and risk ceiling.'})}return {success:true,runId:pr.data.id,status:pr.data.status,portfolioScore:avgSel,confidence:conf,plannedSpend:spend,budgetRemaining:budget-spend,riskExposure:riskExp,coverageScore:coverage,synergyScore:synergy,selected:selected.map((x,i)=>({rank:i+1,creatorId:x.creator.id,name:x.creator.name,cost:x.cost,score:x.candidateScore,objectiveAlignment:x.objectiveAlignment,confidence:x.confidence,risk:x.risk,reason:'Evidence-aware constrained selection'}))}}
async function syncLedgerForCreator(orgId:string,campaignId:string,creatorId:string){
 const {data:preds,error:pe}=await admin.from('prediction_ledger').select('id,predicted_at,lower_bound,upper_bound,evidence').eq('organization_id',orgId).eq('campaign_id',campaignId).eq('creator_id',creatorId).order('predicted_at',{ascending:true});
 if(pe)throw pe;
 const {data:obs,error:oe}=await admin.from('performance_observations').select('*').eq('organization_id',orgId).eq('campaign_id',campaignId).eq('creator_id',creatorId).eq('status','COMPLETED').order('observed_at',{ascending:true});
 if(oe)throw oe;
 for(const row of (preds||[])){
   const actualObs=(obs||[]).find((o:any)=>new Date(String(o.observed_at)).getTime()>=new Date(String(row.predicted_at)).getTime());
   const actual=actualObs?outcome(actualObs,String(actualObs.goal||'AWARENESS')):null;
   const covered=actual!=null&&row.lower_bound!=null&&row.upper_bound!=null&&actual>=Number(row.lower_bound)&&actual<=Number(row.upper_bound);
   const patch:any={actual_score:actual,actual_at:actualObs?.observed_at||null,covered:actual==null?null:covered,evidence:{...(row.evidence||{}),actualPerformanceType:actualObs?performanceType(actualObs):null,actualQuality:actualObs?.quality_score??null}};
   const up=await admin.from('prediction_ledger').update(patch).eq('id',row.id).eq('organization_id',orgId);
   if(up.error)throw up.error;
 }
 return {synced:true,predictions:(preds||[]).length,observations:(obs||[]).length};
}

async function performancePayloadValid(body:any,campaign:any,orgId:string,userId:string){
 const creatorId=String(body.creator_id||'');
 if(!creatorId)throw new Error('creator_id is required');
 const {data:creator,error:creatorErr}=await admin.from('creators').select('id').eq('id',creatorId).eq('organization_id',orgId).maybeSingle();
 if(creatorErr)throw creatorErr;
 if(!creator)throw new Error('Creator not found in organization');
 const observedAt=String(body.observed_at||new Date().toISOString());
 if(new Date(observedAt).getTime()>Date.now()+60000)throw new Error('Observed time cannot be in the future');
 const obs:any={organization_id:orgId,campaign_id:campaign.id,creator_id:creatorId,observed_at:observedAt,status:'COMPLETED',source:String(body.source||'SELF-REPORTED'),goal:String(body.goal||campaign.payload?.objective||'AWARENESS').toUpperCase(),spend_thb:n(body.spend_thb),revenue_thb:n(body.revenue_thb),reach:n(body.reach),impressions:n(body.impressions),views:n(body.views),likes:n(body.likes),comments:n(body.comments),shares:n(body.shares),clicks:n(body.clicks),conversions:n(body.conversions),engagement:n(body.engagement),metadata:body.metadata||{},created_by:userId};
 const v=validate(obs); if(!v.ok)throw Object.assign(new Error('Performance evidence failed validation'),{status:422,validation:v});
 obs.quality_score=v.quality;
 return {obs,v};
}

Deno.serve(async req=>{if(req.method==='OPTIONS')return new Response('ok',{headers});if(req.method!=='POST')return json(405,{error:'POST required'});try{const user=await auth(req);const body=await req.json();const orgId=String(body.organization_id||'');if(!orgId||!(await member(user.id,orgId)))return json(403,{error:'Organization access denied'});if(!(await activeAccess(orgId)))return json(403,{error:'Active KOL IDS subscription required'});const {data:campaign,error:ce}=await admin.from('campaigns').select('*').eq('id',body.campaign_id).eq('organization_id',orgId).single();if(ce||!campaign)return json(404,{error:'Campaign not found'});const {data:audience}=await admin.from('audiences').select('*').eq('campaign_id',campaign.id).eq('organization_id',orgId).order('created_at',{ascending:false}).limit(1).maybeSingle();const {data:allCreators,error:cre}=await admin.from('creators').select('*').eq('organization_id',orgId);if(cre)throw cre;const requestedIds=Array.isArray(body.creator_ids)?body.creator_ids.map((x:any)=>String(x)):[];const creators=(requestedIds.length?(allCreators||[]).filter((x:any)=>requestedIds.includes(String(x.id))):(allCreators||[]));const action=String(body.action||'analyze');if(action==='record_performance'){
 const {obs,v}=await performancePayloadValid(body,campaign,orgId,user.id);
 const ins=await admin.from('performance_observations').insert(obs).select().single();
 if(ins.error)throw ins.error;
 const sync=await syncLedgerForCreator(orgId,campaign.id,String(obs.creator_id));
 return json(200,{success:true,observation:ins.data,actualScore:outcome(obs,obs.goal),validation:v,ledger:sync});
}
if(action==='update_performance'){
 const id=String(body.id||''); if(!id)throw new Error('Performance id is required');
 const {data:existing,error:ee}=await admin.from('performance_observations').select('*').eq('id',id).eq('organization_id',orgId).eq('campaign_id',campaign.id).maybeSingle();
 if(ee)throw ee; if(!existing) return json(404,{error:'Performance observation not found'});
 const {obs,v}=await performancePayloadValid(body,campaign,orgId,user.id);
 const up=await admin.from('performance_observations').update({creator_id:obs.creator_id,observed_at:obs.observed_at,source:obs.source,status:'COMPLETED',goal:obs.goal,spend_thb:obs.spend_thb,revenue_thb:obs.revenue_thb,reach:obs.reach,impressions:obs.impressions,views:obs.views,likes:obs.likes,comments:obs.comments,shares:obs.shares,clicks:obs.clicks,conversions:obs.conversions,engagement:obs.engagement,quality_score:v.quality,validation:v,metadata:obs.metadata,updated_at:new Date().toISOString()}).eq('id',id).eq('organization_id',orgId).eq('campaign_id',campaign.id).select().single();
 if(up.error)throw up.error;
 const syncOld=await syncLedgerForCreator(orgId,campaign.id,String(existing.creator_id));
 const syncNew=String(existing.creator_id)===String(obs.creator_id)?syncOld:await syncLedgerForCreator(orgId,campaign.id,String(obs.creator_id));
 return json(200,{success:true,observation:up.data,actualScore:outcome(obs,obs.goal),validation:v,ledger:{old:syncOld,new:syncNew}});
}
if(action==='delete_performance'){
 const id=String(body.id||''); if(!id)throw new Error('Performance id is required');
 const {data:existing,error:ee}=await admin.from('performance_observations').select('id,creator_id').eq('id',id).eq('organization_id',orgId).eq('campaign_id',campaign.id).maybeSingle();
 if(ee)throw ee; if(!existing) return json(404,{error:'Performance observation not found'});
 const del=await admin.from('performance_observations').delete().eq('id',id).eq('organization_id',orgId).eq('campaign_id',campaign.id);
 if(del.error)throw del.error;
 const sync=await syncLedgerForCreator(orgId,campaign.id,String(existing.creator_id));
 return json(200,{success:true,deletedId:id,ledger:sync});
}
if(action==='sync_performance_ledger'){
 const creatorId=String(body.creator_id||''); if(!creatorId)throw new Error('creator_id is required');
 const sync=await syncLedgerForCreator(orgId,campaign.id,creatorId);
 return json(200,{success:true,ledger:sync});
}
if(action==='analyze')return json(200,await runAnalysis(orgId,campaign,audience,creators||[],user.id));if(action==='portfolio')return json(200,await portfolio(orgId,campaign,creators||[],user.id));if(action==='calibration'){const goal=String(campaign.payload?.objective||'AWARENESS').toUpperCase();return json(200,{success:true,modelVersion:MODEL,goal,calibration:await calibration(orgId,goal,new Date().toISOString())});}if(action==='backtest'){const goal=String(campaign.payload?.objective||'AWARENESS').toUpperCase();const {data,error}=await admin.from('prediction_ledger').select('*').eq('organization_id',orgId).eq('goal',goal).not('actual_score','is',null);if(error)throw error;const arr=data||[];const errs=arr.map(x=>Number(x.actual_score)-Number(x.predicted_score));const abs=errs.map(x=>Math.abs(x));return json(200,{success:true,modelVersion:MODEL,goal,n:arr.length,mae:mean(abs),bias:mean(errs),medianAbsError:q(abs,.5),intervalCoverage80:arr.length?mean(arr.map(x=>x.covered?1:0)):null,status:arr.length>=CFG.MIN_TRUST_EVIDENCE?'BACKTEST_READY':'INSUFFICIENT_HISTORY',learning:'OOS residual calibration + creator-level correction + recency weighting'});}return json(400,{error:'Unknown action'});}catch(e){const status=Number((e as any)?.status)||500;return json(status,{error:e instanceof Error?e.message:'Intelligence engine failed',validation:(e as any)?.validation||undefined});}});
