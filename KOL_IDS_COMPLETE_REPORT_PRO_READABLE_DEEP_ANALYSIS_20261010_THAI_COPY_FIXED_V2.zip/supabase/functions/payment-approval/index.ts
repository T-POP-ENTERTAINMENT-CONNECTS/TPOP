import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const url = Deno.env.get('SUPABASE_URL')!;
const secretKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || JSON.parse(Deno.env.get('SUPABASE_SECRET_KEYS') || '{}').default;
const approvalSecret = Deno.env.get('KOL_IDS_PAYMENT_APPROVAL_SECRET') || '';
const resendApiKey = Deno.env.get('RESEND_API_KEY') || '';
const emailFrom = Deno.env.get('KOL_IDS_EMAIL_FROM') || '';
const customerLoginUrl = Deno.env.get('KOL_IDS_CUSTOMER_LOGIN_URL') || 'https://tpopconnects.com/KOLIDS';
if (!secretKey) throw new Error('Supabase secret key is not configured');
const admin = createClient(url, secretKey, {auth:{autoRefreshToken:false,persistSession:false}});
const headers = {'Content-Type':'application/json','Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'content-type,x-kol-ids-approval-secret','Access-Control-Allow-Methods':'POST,OPTIONS'};
const json=(s:number,b:unknown)=>new Response(JSON.stringify(b),{status:s,headers});

async function hmacHex(secret:string,value:string){
  const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);
  const sig=await crypto.subtle.sign('HMAC',key,new TextEncoder().encode(value));
  return [...new Uint8Array(sig)].map(x=>x.toString(16).padStart(2,'0')).join('');
}


async function sendActivationEmail(order:any, plan:any, expiresAt:string){
  const to=String(order.customer_email||'').trim();
  if(!to) return {sent:false,error:'Customer email is missing'};
  if(!resendApiKey || !emailFrom) return {sent:false,error:'RESEND_API_KEY or KOL_IDS_EMAIL_FROM is not configured'};
  const planName=String(plan?.name||order.plan_code||'paid');
  const planCode=String(plan?.code||order.plan_code||'');
  const amount=Number(order.amount_thb);
  const durationDays=Number(plan?.duration_days);
  const amountLabel=Number.isFinite(amount)?`THB ${amount.toLocaleString('en-US',{minimumFractionDigits:0,maximumFractionDigits:2})}`:'Not recorded';
  const durationLabel=Number.isFinite(durationDays)?`${durationDays} days`:'Not recorded';
  const expiresLabel=new Date(expiresAt).toLocaleString('en-GB',{dateStyle:'medium',timeStyle:'short',timeZone:'Asia/Bangkok'});
  const subject=`KOL IDS · Account approved · ${order.order_number}`;
  const html=`<div style="font-family:Arial,sans-serif;max-width:680px;color:#111"><h2 style="margin:0 0 8px">Your KOL IDS™ account is approved.</h2><p>Your payment for order <b>${String(order.order_number)}</b> has been verified and your account is now active.</p><table cellpadding=7 cellspacing=0 style="border-collapse:collapse;width:100%;font-size:14px;margin:18px 0"><tr><td><b>Plan</b></td><td>${planName}</td></tr><tr><td><b>Plan code</b></td><td>${planCode}</td></tr><tr><td><b>Amount paid</b></td><td>${amountLabel}</td></tr><tr><td><b>Duration</b></td><td>${durationLabel}</td></tr><tr><td><b>Access until</b></td><td>${expiresLabel} (Bangkok time)</td></tr></table><p style="margin:24px 0"><a href="${customerLoginUrl}" style="display:inline-block;background:#111;color:#fff;text-decoration:none;padding:14px 22px;border-radius:8px;font-weight:700">OPEN KOL IDS</a></p><p style="color:#666;font-size:13px">Sign in with the work email used for your application.</p><p style="font-size:12px;color:#888">KOL IDS™ · Creator Decision Intelligence</p></div>`;
  const text=`Your KOL IDS account is approved. Order ${order.order_number} is now active. Plan: ${planName}. Plan code: ${planCode}. Amount paid: ${amountLabel}. Duration: ${durationLabel}. Access until: ${expiresLabel} (Bangkok time). Sign in at ${customerLoginUrl}`;
  const r=await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:`Bearer ${resendApiKey}`,'Content-Type':'application/json'},body:JSON.stringify({from:emailFrom,to:[to],subject,html,text})});
  const body=await r.text();
  if(!r.ok) return {sent:false,error:`Email provider failed (${r.status}): ${body.slice(0,300)}`};
  return {sent:true};
}

Deno.serve(async req=>{
  if(req.method==='OPTIONS') return new Response('ok',{headers});
  if(req.method!=='POST') return json(405,{error:'POST required'});
  try{
    if(!approvalSecret) return json(503,{error:'Approval secret is not configured'});
    const supplied=req.headers.get('x-kol-ids-approval-secret')||'';
    // The Apps Script holds the same secret, but we compare it through HMAC to
    // avoid putting a raw secret in logs or response bodies.
    const check=await hmacHex(approvalSecret,'KOL_IDS_PAYMENT_APPROVAL_AUTH');
    const suppliedCheck=await hmacHex(supplied,'KOL_IDS_PAYMENT_APPROVAL_AUTH');
    if(suppliedCheck!==check) return json(401,{error:'Unauthorized'});

    const body=await req.json();
    const orderNumber=String(body.order_number||'').trim();
    const action=String(body.action||'').trim().toLowerCase();
    if(!orderNumber||!['approve','reject','details'].includes(action)) return json(400,{error:'order_number and valid action are required'});

    const {data:order,error:oe}=await admin.from('customer_orders').select('*').eq('order_number',orderNumber).single();
    if(oe||!order) return json(404,{error:'Order not found'});
    if(action==='details') return json(200,{ok:true,action:'details',order:{id:order.id,order_number:order.order_number,customer_email:order.customer_email,plan_code:order.plan_code,amount_thb:order.amount_thb,status:order.status,payment_status:order.payment_status,payload:order.payload||{}}});
    if(['approved','cancelled','failed','expired'].includes(String(order.status))){
      if(action==='approve' && order.status==='approved'){
        const {data:sub}=await admin.from('subscriptions').select('expires_at,plan_code').eq('order_id',order.id).order('created_at',{ascending:false}).limit(1).maybeSingle();
        return json(200,{ok:true,already_processed:true,customer_email:order.customer_email,plan_code:sub?.plan_code||order.plan_code,expires_at:sub?.expires_at||null});
      }
      return json(409,{error:'Order has already been processed'});
    }

    if(action==='reject'){
      const now=new Date().toISOString();
      const up=await admin.from('customer_orders').update({status:'cancelled',payment_status:'failed',updated_at:now}).eq('id',order.id);
      if(up.error) throw up.error;
      const sub=await admin.from('subscriptions').update({status:'cancelled',updated_at:now}).eq('order_id',order.id).eq('status','pending');
      if(sub.error) throw sub.error;
      await admin.from('subscription_events').insert({order_id:order.id,organization_id:order.organization_id,event_type:'payment_rejected',provider:'google_form',payload:{source:'email_approval'}});
      return json(200,{ok:true,action:'reject',customer_email:order.customer_email,plan_code:order.plan_code,expires_at:null});
    }

    const {data:plan,error:pe}=await admin.from('plans').select('*').eq('code',order.plan_code).eq('active',true).single();
    if(pe||!plan) return json(400,{error:'Plan not found'});
    const now=new Date();
    const expires=new Date(now.getTime()+Number(plan.duration_days)*86400000);

    // Cancel any previous active subscription, then activate this paid order.
    const c=await admin.from('subscriptions').update({status:'cancelled',updated_at:now.toISOString()}).eq('organization_id',order.organization_id).eq('status','active');
    if(c.error) throw c.error;
    const {data:existing,error:se}=await admin.from('subscriptions').select('id').eq('order_id',order.id).order('created_at',{ascending:false}).limit(1).maybeSingle();
    if(se) throw se;
    let subscriptionId='';
    if(existing?.id){
      const u=await admin.from('subscriptions').update({status:'active',starts_at:now.toISOString(),expires_at:expires.toISOString(),approved_at:now.toISOString(),updated_at:now.toISOString()}).eq('id',existing.id).select('id').single();
      if(u.error) throw u.error; subscriptionId=u.data.id;
    }else{
      const i=await admin.from('subscriptions').insert({organization_id:order.organization_id,plan_code:order.plan_code,order_id:order.id,status:'active',starts_at:now.toISOString(),expires_at:expires.toISOString(),approved_at:now.toISOString()}).select('id').single();
      if(i.error) throw i.error; subscriptionId=i.data.id;
    }
    const ou=await admin.from('customer_orders').update({status:'approved',payment_status:'paid',paid_at:now.toISOString(),approved_at:now.toISOString(),provider:'google_form',provider_reference:`EMAIL_APPROVAL_${order.order_number}`,updated_at:now.toISOString()}).eq('id',order.id);
    if(ou.error) throw ou.error;
    const ev=await admin.from('subscription_events').insert({subscription_id:subscriptionId,organization_id:order.organization_id,order_id:order.id,event_type:'subscription_activated',provider:'email_approval',provider_event_id:`EMAIL_APPROVAL_${order.order_number}`,payload:{source:'email_approval'}});
    if(ev.error) throw ev.error;

    const activationEmail=await sendActivationEmail(order,plan,expires.toISOString());
    return json(200,{ok:true,action:'approve',customer_email:order.customer_email,plan_code:order.plan_code,expires_at:expires.toISOString(),subscription_id:subscriptionId,activation_email_sent:activationEmail.sent,activation_email_error:activationEmail.error||null});
  }catch(e){return json(500,{error:e instanceof Error?e.message:'Payment approval failed'});}
});
