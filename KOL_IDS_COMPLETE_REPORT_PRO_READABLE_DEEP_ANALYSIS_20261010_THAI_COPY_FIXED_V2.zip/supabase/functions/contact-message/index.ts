const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (body: Record<string, unknown>, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

const clean = (value: unknown, max = 5000) =>
  String(value ?? "").trim().slice(0, max);

const esc = (value: string) => value
  .replaceAll("&", "&amp;")
  .replaceAll("<", "&lt;")
  .replaceAll(">", "&gt;")
  .replaceAll('"', "&quot;")
  .replaceAll("'", "&#39;");

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ ok: false, error: "Method not allowed" }, 405);

  const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY") || "";
  const FROM = Deno.env.get("KOL_IDS_EMAIL_FROM") || "";
  const TO_RAW = Deno.env.get("KOL_IDS_CONTACT_TO") || "";

  if (!RESEND_API_KEY || !FROM || !TO_RAW) {
    console.error("Missing contact email configuration", {
      hasResendApiKey: !!RESEND_API_KEY,
      hasFrom: !!FROM,
      hasTo: !!TO_RAW,
    });
    return json({ ok: false, error: "Contact email service is not configured" }, 500);
  }

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return json({ ok: false, error: "Invalid request body" }, 400);
  }

  const name = clean(body.name, 200);
  const email = clean(body.email, 320);
  const company = clean(body.company, 300);
  const topic = clean(body.topic, 120);
  const other = clean(body.other, 500);
  const message = clean(body.message, 5000);
  const source = clean(body.source, 1000);

  if (!name || !email || !topic || !message) {
    return json({ ok: false, error: "Please complete all required fields" }, 400);
  }

  const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  if (!emailOk) return json({ ok: false, error: "Please enter a valid email address" }, 400);

  // Supports comma, semicolon, or newline separated recipients.
  const recipients = TO_RAW.split(/[;,\n]+/).map((v) => v.trim()).filter(Boolean);
  if (!recipients.length) return json({ ok: false, error: "No contact recipient configured" }, 500);

  const subject = `[KOL IDS Contact] ${topic || "General inquiry"}`;
  const text = [
    "New contact form submission",
    "",
    `Name: ${name}`,
    `Email: ${email}`,
    `Company / Organization: ${company || "Not provided"}`,
    `Topic: ${topic}`,
    other ? `Details: ${other}` : "",
    "",
    "Message:",
    message,
    "",
    `Source: ${source || "KOL IDS website"}`,
  ].filter(Boolean).join("\n");

  const html = `
    <div style="font-family:Arial,sans-serif;max-width:720px;color:#111;line-height:1.6">
      <h2 style="margin:0 0 18px">New KOL IDS contact request</h2>
      <table style="border-collapse:collapse;width:100%;font-size:14px">
        <tr><td style="padding:8px 0;color:#666;width:190px">Name</td><td style="padding:8px 0"><b>${esc(name)}</b></td></tr>
        <tr><td style="padding:8px 0;color:#666">Email</td><td style="padding:8px 0">${esc(email)}</td></tr>
        <tr><td style="padding:8px 0;color:#666">Company / Organization</td><td style="padding:8px 0">${esc(company || "Not provided")}</td></tr>
        <tr><td style="padding:8px 0;color:#666">Topic</td><td style="padding:8px 0">${esc(topic)}</td></tr>
        ${other ? `<tr><td style="padding:8px 0;color:#666">Details</td><td style="padding:8px 0">${esc(other)}</td></tr>` : ""}
      </table>
      <div style="margin-top:20px;padding:18px;background:#f5f5f3;border-radius:10px;white-space:pre-wrap">${esc(message)}</div>
      <p style="margin-top:20px;color:#777;font-size:12px">Source: ${esc(source || "KOL IDS website")}</p>
    </div>`;

  try {
    const resend = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${RESEND_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: FROM,
        to: recipients,
        reply_to: email,
        subject,
        text,
        html,
      }),
    });

    const result = await resend.json().catch(() => ({}));
    console.log("Contact email result", { status: resend.status, result });

    if (!resend.ok) {
      return json({ ok: false, error: "Email provider rejected the message", provider: result }, 502);
    }

    return json({ ok: true, id: result?.id || null });
  } catch (error) {
    console.error("Contact email request failed", error);
    return json({ ok: false, error: "Unable to send contact email" }, 502);
  }
});
