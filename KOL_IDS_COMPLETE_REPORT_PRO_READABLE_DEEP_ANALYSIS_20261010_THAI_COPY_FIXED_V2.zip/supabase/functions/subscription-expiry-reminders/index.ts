import { createClient } from 'npm:@supabase/supabase-js@2'

const SUPABASE_URL = Deno.env.get('SUPABASE_URL') || ''
const SERVICE_ROLE = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || (() => {
  try { return JSON.parse(Deno.env.get('SUPABASE_SECRET_KEYS') || '{}').default || '' } catch { return '' }
})()
const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY') || ''
const EMAIL_FROM = Deno.env.get('KOL_IDS_EMAIL_FROM') || ''
const CRON_SECRET = Deno.env.get('KOL_IDS_EXPIRY_REMINDER_SECRET') || ''
const LOGIN_URL = Deno.env.get('KOL_IDS_CUSTOMER_LOGIN_URL') || 'https://tpopconnects.com/KOLIDS'

const admin = SERVICE_ROLE ? createClient(SUPABASE_URL, SERVICE_ROLE, { auth: { autoRefreshToken: false, persistSession: false } }) : null
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' } })
const esc = (v: unknown) => String(v ?? '').replace(/[&<>'"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[c] || c))
const money = (v: unknown) => {
  const n = Number(v)
  return Number.isFinite(n) ? `THB ${n.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}` : 'Not recorded'
}

function requireConfig() {
  const missing = [
    !SUPABASE_URL && 'SUPABASE_URL',
    !SERVICE_ROLE && 'SUPABASE_SERVICE_ROLE_KEY',
    !RESEND_API_KEY && 'RESEND_API_KEY',
    !EMAIL_FROM && 'KOL_IDS_EMAIL_FROM',
    !CRON_SECRET && 'KOL_IDS_EXPIRY_REMINDER_SECRET',
  ].filter(Boolean)
  if (missing.length || !admin) throw new Error(`Missing Edge Function configuration: ${missing.join(', ') || 'admin client'}`)
}

function bangkokDate(value: string) {
  return new Date(value).toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short', timeZone: 'Asia/Bangkok' })
}

async function sendEmail(to: string, subject: string, html: string, text: string) {
  const r = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { Authorization: `Bearer ${RESEND_API_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ from: EMAIL_FROM, to: [to], subject, html, text }),
  })
  const raw = await r.text()
  if (!r.ok) throw new Error(`Resend failed (${r.status}): ${raw.slice(0, 300)}`)
}

async function claimReminder(subscriptionId: string, reminderCode: string) {
  const existing = await admin!.from('subscription_expiry_notifications')
    .select('id,status')
    .eq('subscription_id', subscriptionId)
    .eq('reminder_code', reminderCode)
    .maybeSingle()
  if (existing.error) throw existing.error
  if (existing.data?.status === 'sent' || existing.data?.status === 'sending') return null
  if (existing.data?.id) {
    const retry = await admin!.from('subscription_expiry_notifications').update({
      status: 'sending',
      attempted_at: new Date().toISOString(),
      error_message: null,
      updated_at: new Date().toISOString(),
    }).eq('id', existing.data.id).eq('status', 'failed').select('id').maybeSingle()
    if (retry.error) throw retry.error
    return retry.data?.id || null
  }
  const created = await admin!.from('subscription_expiry_notifications').insert({
    subscription_id: subscriptionId,
    reminder_code: reminderCode,
    status: 'sending',
    attempted_at: new Date().toISOString(),
  }).select('id').maybeSingle()
  if (created.error && created.error.code === '23505') return null
  if (created.error) throw created.error
  return created.data?.id || null
}

async function finishReminder(id: string, status: 'sent'|'failed', errorMessage = '') {
  await admin!.from('subscription_expiry_notifications').update({
    status,
    sent_at: status === 'sent' ? new Date().toISOString() : null,
    error_message: errorMessage || null,
    updated_at: new Date().toISOString(),
  }).eq('id', id)
}

Deno.serve(async req => {
  if (req.method === 'OPTIONS') return new Response('ok')
  if (req.method !== 'POST') return json({ error: 'POST required' }, 405)
  try {
    requireConfig()
    const supplied = req.headers.get('x-kol-ids-expiry-secret') || ''
    if (!supplied || supplied !== CRON_SECRET) return json({ error: 'Unauthorized' }, 401)

    const now = new Date()
    const horizon = new Date(now.getTime() + 31 * 24 * 60 * 60 * 1000)
    const { data: subs, error } = await admin!.from('subscriptions')
      .select('id,organization_id,plan_code,order_id,status,starts_at,expires_at,plans:plan_code(code,name,duration_days,price_thb,is_trial),organizations:organization_id(id,name,created_by)')
      .eq('status', 'active')
      .gt('expires_at', now.toISOString())
      .lte('expires_at', horizon.toISOString())
      .order('expires_at', { ascending: true })
    if (error) throw error

    const summary = { checked: subs?.length || 0, sent: 0, skipped: 0, failed: 0, details: [] as any[] }

    for (const sub of (subs || [])) {
      const plan: any = Array.isArray(sub.plans) ? sub.plans[0] : sub.plans
      if (!plan) { summary.skipped++; continue }
      const isTrial = Boolean(plan.is_trial)
      const reminderCode = isTrial ? 'TRIAL_3_DAYS' : 'PAID_30_DAYS'
      const thresholdDays = isTrial ? 3 : 30
      const secondsLeft = (new Date(sub.expires_at).getTime() - now.getTime()) / 1000
      // Send only inside the intended daily window so the reminder is tied to the actual lead time.
      // Trial: 2–3 days remaining. Paid: 29–30 days remaining.
      if (secondsLeft > thresholdDays * 86400 || secondsLeft <= (thresholdDays - 1) * 86400) {
        summary.skipped++
        continue
      }

      const logId = await claimReminder(sub.id, reminderCode)
      if (!logId) { summary.skipped++; continue }
      try {
        let recipient = ''
        let order: any = null
        if (sub.order_id) {
          const r = await admin!.from('customer_orders').select('order_number,customer_email,amount_thb').eq('id', sub.order_id).maybeSingle()
          if (r.error) throw r.error
          order = r.data
          recipient = String(order?.customer_email || '').trim().toLowerCase()
        }
        if (!recipient) {
          const r = await admin!.from('profiles').select('email').eq('user_id', sub.organizations?.created_by).maybeSingle()
          if (r.error) throw r.error
          recipient = String(r.data?.email || '').trim().toLowerCase()
        }
        if (!recipient) throw new Error('Customer email could not be resolved')

        const amountLabel = isTrial ? 'FREE' : money(order?.amount_thb ?? plan.price_thb)
        const planName = String(plan.name || plan.code)
        const expiryLabel = bangkokDate(sub.expires_at)
        const organizationName = String(sub.organizations?.name || 'your organization')
        const subject = isTrial
          ? `KOL IDS · Your 7-Day Trial expires in 3 days`
          : `KOL IDS · Your ${planName} plan expires in 30 days`
        const title = isTrial ? 'Your 7-Day Trial expires in 3 days' : `Your ${planName} subscription expires in 30 days`
        const actionText = isTrial
          ? 'Your free trial is approaching its end date. Upgrade before the expiry date to keep workspace access.'
          : 'Your current paid subscription is approaching its end date. Renew before the expiry date to keep workspace access without interruption.'
        const html = `<div style="font-family:Arial,sans-serif;max-width:680px;color:#111"><div style="font-size:11px;letter-spacing:.14em;color:#777;font-weight:800">KOL IDS™ · SUBSCRIPTION REMINDER</div><h2 style="margin:10px 0 8px">${esc(title)}</h2><p>${esc(actionText)}</p><table cellpadding="8" cellspacing="0" style="border-collapse:collapse;width:100%;font-size:14px;margin:18px 0"><tr><td><b>Organization</b></td><td>${esc(organizationName)}</td></tr><tr><td><b>Plan</b></td><td>${esc(planName)}</td></tr><tr><td><b>Price</b></td><td>${esc(amountLabel)}</td></tr><tr><td><b>Duration</b></td><td>${esc(plan.duration_days)} days</td></tr><tr><td><b>Access until</b></td><td>${esc(expiryLabel)} (Bangkok time)</td></tr></table><p style="margin:24px 0"><a href="${esc(LOGIN_URL)}" style="display:inline-block;background:#111;color:#fff;text-decoration:none;padding:14px 22px;border-radius:8px;font-weight:700">OPEN KOL IDS</a></p><p style="color:#666;font-size:13px">If you have already renewed this organization, you can ignore this reminder.</p><p style="font-size:12px;color:#888">KOL IDS™ · Investment Decision Intelligence</p></div>`
        const text = `KOL IDS subscription reminder\nOrganization: ${organizationName}\nPlan: ${planName}\nPrice: ${amountLabel}\nDuration: ${plan.duration_days} days\nAccess until: ${expiryLabel} (Bangkok time)\n${actionText}\nOpen KOL IDS: ${LOGIN_URL}`
        await sendEmail(recipient, subject, html, text)
        if (logId) await finishReminder(logId, 'sent')
        summary.sent++
        summary.details.push({ subscription_id: sub.id, reminder: reminderCode, email: recipient, status: 'sent' })
      } catch (e) {
        if (logId) await finishReminder(logId, 'failed', e instanceof Error ? e.message : String(e))
        summary.failed++
        summary.details.push({ subscription_id: sub.id, reminder: reminderCode, status: 'failed', error: e instanceof Error ? e.message : String(e) })
      }
    }

    return json({ ok: true, ...summary })
  } catch (e) {
    return json({ ok: false, error: e instanceof Error ? e.message : String(e) }, 500)
  }
})
