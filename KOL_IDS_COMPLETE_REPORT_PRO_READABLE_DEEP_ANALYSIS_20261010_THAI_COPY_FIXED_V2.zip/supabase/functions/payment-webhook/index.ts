import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const url=Deno.env.get('SUPABASE_URL')!;
const secretKey=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || JSON.parse(Deno.env.get('SUPABASE_SECRET_KEYS') || '{}').default;
const webhookSecret=Deno.env.get('KOL_IDS_PAYMENT_WEBHOOK_SECRET');
if(!secretKey) throw new Error('Supabase secret key is not configured');
const admin=createClient(url,secretKey,{auth:{autoRefreshToken:false,persistSession:false}});
const headers={'Content-Type':'application/json','Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'content-type,x-kol-ids-signature'};
const json=(s:number,b:unknown)=>new Response(JSON.stringify(b),{status:s,headers});

async function hmacHex(secret:string,body:string){
  const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);
  const sig=await crypto.subtle.sign('HMAC',key,new TextEncoder().encode(body));
  return [...new Uint8Array(sig)].map(x=>x.toString(16).padStart(2,'0')).join('');
}

Deno.serve(async req=>{
  if(req.method==='OPTIONS') return new Response('ok',{headers});
  if(req.method!=='POST') return json(405,{error:'POST required'});
  try{
    if(!webhookSecret) return json(503,{error:'Payment webhook secret is not configured'});
    const raw=await req.text();
    const supplied=req.headers.get('x-kol-ids-signature')||'';
    const expected=await hmacHex(webhookSecret,raw);
    if(supplied!==expected) return json(401,{error:'Invalid signature'});
    const body=JSON.parse(raw);
    const orderId=String(body.order_id||'');
    const eventId=String(body.event_id||body.provider_event_id||'');
    const provider=String(body.provider||'external');
    const paymentStatus=String(body.payment_status||body.status||'paid').toLowerCase();
    if(!orderId||!eventId) return json(400,{error:'order_id and event_id are required'});

    const {data:existing}=await admin.from('subscription_events').select('id').eq('provider',provider).eq('provider_event_id',eventId).maybeSingle();
    if(existing) return json(200,{ok:true,duplicate:true});

    if(paymentStatus!=='paid'){
      await admin.from('subscription_events').insert({order_id:orderId,event_type:`payment_${paymentStatus}`,provider,provider_event_id:eventId,payload:body});
      return json(200,{ok:true,processed:paymentStatus});
    }

    const {data:order}=await admin.from('customer_orders').select('id,organization_id,plan_code,status').eq('id',orderId).single();
    if(!order) return json(404,{error:'Order not found'});

    // The activation RPC requires a platform admin JWT, so this webhook performs
    // the equivalent server-side operation under the service key after validating
    // the signed provider event. No browser can invoke this path.
    const {data:plan}=await admin.from('plans').select('*').eq('code',order.plan_code).single();
    if(!plan) return json(400,{error:'Plan not found'});

    await admin.from('subscriptions').update({status:'cancelled',updated_at:new Date().toISOString()}).eq('organization_id',order.organization_id).eq('status','active');
    const {data:sub}=await admin.from('subscriptions').select('*').eq('order_id',order.id).order('created_at',{ascending:false}).limit(1).maybeSingle();
    const starts=new Date();
    const expires=new Date(starts.getTime()+Number(plan.duration_days)*86400000);
    let subId=sub?.id;
    if(sub){
      await admin.from('subscriptions').update({status:'active',starts_at:starts.toISOString(),expires_at:expires.toISOString(),approved_at:starts.toISOString(),updated_at:starts.toISOString()}).eq('id',sub.id);
    }else{
      const ins=await admin.from('subscriptions').insert({organization_id:order.organization_id,plan_code:order.plan_code,order_id:order.id,status:'active',starts_at:starts.toISOString(),expires_at:expires.toISOString(),approved_at:starts.toISOString()}).select().single();
      if(ins.error) throw ins.error;
      subId=ins.data.id;
    }
    await admin.from('customer_orders').update({status:'approved',payment_status:'paid',paid_at:starts.toISOString(),approved_at:starts.toISOString(),provider,provider_reference:String(body.provider_reference||eventId),updated_at:starts.toISOString()}).eq('id',order.id);
    await admin.from('subscription_events').insert({subscription_id:subId,organization_id:order.organization_id,order_id:order.id,event_type:'subscription_activated',provider,provider_event_id:eventId,payload:body});
    return json(200,{ok:true,activated:true,subscription_id:subId});
  }catch(e){return json(500,{error:e instanceof Error?e.message:'Webhook processing failed'});}
});
