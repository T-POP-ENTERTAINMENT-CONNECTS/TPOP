import { createClient } from 'npm:@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': 'https://tpopconnects.com',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
}

const SUPABASE_URL = Deno.env.get('SUPABASE_URL') || ''
const SECRET_KEYS = (() => {
  try { return JSON.parse(Deno.env.get('SUPABASE_SECRET_KEYS') || '{}') } catch { return {} }
})()
const SERVICE_ROLE = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || SECRET_KEYS.default || ''
const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY') || ''
const EMAIL_FROM = Deno.env.get('KOL_IDS_EMAIL_FROM') || ''
const ADMIN_EMAILS = (Deno.env.get('KOL_IDS_PAYMENT_ADMIN_EMAILS') || '').split(',').map(v => v.trim()).filter(Boolean)
const APPROVAL_SECRET = Deno.env.get('KOL_IDS_SIGNUP_APPROVAL_SECRET') || ''
const PAYMENT_APPROVAL_SECRET = Deno.env.get('KOL_IDS_PAYMENT_APPROVAL_SECRET') || ''
const CUSTOMER_LOGIN_URL = Deno.env.get('KOL_IDS_CUSTOMER_LOGIN_URL') || 'https://tpopconnects.com/KOLIDS'
const APPROVAL_PAGE_URL = Deno.env.get('KOL_IDS_APPROVAL_PAGE_URL') || 'https://tpopconnects.com/approval.html'
const BUCKET = 'payment-proofs'

const admin = SERVICE_ROLE ? createClient(SUPABASE_URL, SERVICE_ROLE, { auth: { autoRefreshToken: false, persistSession: false } }) : null

const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
const html = (body: string, status = 200) => new Response(body, { status, headers: { ...corsHeaders, 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store, no-cache, must-revalidate', 'X-Content-Type-Options': 'nosniff' } })
const esc = (v: unknown) => String(v ?? '').replace(/[&<>'"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[c] || c))
const money = (v: unknown) => {
  const n = Number(v)
  return Number.isFinite(n) ? n.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 }) : String(v ?? '·')
}

function requireConfig() {
  const missing = [
    !SUPABASE_URL && 'SUPABASE_URL', !SERVICE_ROLE && 'SUPABASE_SECRET_KEY', !RESEND_API_KEY && 'RESEND_API_KEY',
    !EMAIL_FROM && 'KOL_IDS_EMAIL_FROM', !ADMIN_EMAILS.length && 'KOL_IDS_PAYMENT_ADMIN_EMAILS',
    !APPROVAL_SECRET && 'KOL_IDS_SIGNUP_APPROVAL_SECRET', !PAYMENT_APPROVAL_SECRET && 'KOL_IDS_PAYMENT_APPROVAL_SECRET'
  ].filter(Boolean)
  if (missing.length) throw new Error(`Missing Edge Function secrets: ${missing.join(', ')}`)
  if (!admin) throw new Error('Supabase admin client is not configured')
}

function b64url(bytes: Uint8Array) {
  let binary = ''
  bytes.forEach(b => binary += String.fromCharCode(b))
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '')
}
function unb64url(s: string) {
  const padded = s.replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((s.length + 3) % 4)
  const binary = atob(padded)
  return Uint8Array.from(binary, c => c.charCodeAt(0))
}
async function hmac(value: string, secret = APPROVAL_SECRET) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign', 'verify'])
  return new Uint8Array(await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(value)))
}
async function makeToken(orderNumber: string, action: 'approve'|'reject') {
  const payload = JSON.stringify({ order_number: orderNumber, action, exp: Math.floor(Date.now() / 1000) + 24 * 60 * 60 })
  const sig = b64url(await hmac(payload))
  return `${b64url(new TextEncoder().encode(payload))}.${sig}`
}
async function readToken(token: string) {
  const [payload64, sig64] = String(token || '').split('.')
  if (!payload64 || !sig64) throw new Error('Invalid approval link')
  const payloadBytes = unb64url(payload64)
  const payload = new TextDecoder().decode(payloadBytes)
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(APPROVAL_SECRET), { name: 'HMAC', hash: 'SHA-256' }, false, ['verify'])
  const ok = await crypto.subtle.verify('HMAC', key, unb64url(sig64), new TextEncoder().encode(payload))
  if (!ok) throw new Error('Invalid approval link signature')
  const parsed = JSON.parse(payload)
  if (!parsed.order_number || !['approve', 'reject'].includes(parsed.action) || Number(parsed.exp) < Math.floor(Date.now() / 1000)) throw new Error('This approval link has expired or is invalid')
  return parsed as { order_number: string, action: 'approve'|'reject', exp: number }
}

async function sendEmail(to: string|string[], subject: string, htmlBody: string, textBody: string) {
  const recipients = Array.isArray(to) ? to : [to]
  const r = await fetch('https://api.resend.com/emails', {
    method: 'POST', headers: { Authorization: `Bearer ${RESEND_API_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ from: EMAIL_FROM, to: recipients, subject, html: htmlBody, text: textBody })
  })
  const body = await r.text()
  if (!r.ok) throw new Error(`Email provider failed (${r.status}): ${body.slice(0, 300)}`)
  return JSON.parse(body || '{}')
}

async function ensureBucket() {
  if (!admin) throw new Error('Supabase admin client is not configured')
  const existing = await admin.storage.getBucket(BUCKET)
  if (!existing.error && existing.data) return
  const created = await admin.storage.createBucket(BUCKET, { public: false, fileSizeLimit: 8 * 1024 * 1024, allowedMimeTypes: ['image/jpeg','image/png','image/webp','application/pdf'] })
  if (created.error && !/already exists|duplicate/i.test(created.error.message || '')) throw created.error
}

async function getOrder(orderNumber: string) {
  if (!admin) throw new Error('Supabase admin client is not configured')
  const q = await admin.from('customer_orders').select('*').eq('order_number', orderNumber).maybeSingle()
  if (q.error) throw q.error
  if (!q.data) throw new Error('Order not found')
  return q.data as any
}

async function updateOrderPayload(order: any, patch: Record<string, unknown>) {
  const payload = (order.payload && typeof order.payload === 'object') ? { ...order.payload } : {}
  payload.payment = { ...(payload.payment || {}), ...patch }
  const updated = await admin!.from('customer_orders').update({ payload }).eq('id', order.id)
  if (updated.error) throw updated.error
  return payload
}

async function authUser(req: Request) {
  const auth = req.headers.get('authorization') || ''
  const token = auth.replace(/^Bearer\s+/i, '').trim()
  if (!token) throw new Error('Authentication required')
  const result = await admin!.auth.getUser(token)
  if (result.error || !result.data.user) throw new Error('Authentication expired. Please sign in again.')
  return result.data.user
}

function orderBelongsToUser(order: any, user: any) {
  const uid = String(user?.id || '')
  const email = String(user?.email || '').trim().toLowerCase()
  const requestedBy = String(order?.requested_by || '').trim()
  const legacyUserId = String(order?.user_id || '').trim()
  const customerEmail = String(order?.customer_email || '').trim().toLowerCase()
  return Boolean(
    uid && (requestedBy === uid || legacyUserId === uid) ||
    email && customerEmail && email === customerEmail
  )
}

async function prepareUpload(req: Request, body: any) {
  const user = await authUser(req)
  const order = await getOrder(String(body.order_number || ''))
  if (!orderBelongsToUser(order, user)) {
    throw new Error('This order is not linked to the signed-in account. Please sign in with the same email used to create the order.')
  }
  await ensureBucket()
  const safeName = String(body.file_name || 'payment-proof').replace(/[^a-zA-Z0-9._-]/g, '_').slice(-120)
  const path = `${user.id}/${order.order_number}/${crypto.randomUUID()}-${safeName}`
  const signed = await admin!.storage.from(BUCKET).createSignedUploadUrl(path, { upsert: false })
  if (signed.error) throw signed.error
  return json({ ok: true, path, token: signed.data.token })
}

async function getPlanSnapshot(order: any) {
  const { data: plan, error } = await admin!.from('plans').select('code,name,duration_days,price_thb').eq('code', String(order.plan_code || '')).eq('active', true).maybeSingle()
  if (error) throw error
  if (!plan) throw new Error(`Active plan ${String(order.plan_code || '·')} was not found. Payment email was not sent.`)
  const orderAmount = Number(order.amount_thb)
  const catalogAmount = Number(plan.price_thb)
  return {
    code: String(plan.code),
    name: String(plan.name || plan.code),
    durationDays: Number(plan.duration_days),
    priceThb: Number.isFinite(orderAmount) ? orderAmount : catalogAmount,
    catalogPriceThb: catalogAmount,
    priceMismatch: Number.isFinite(orderAmount) && Number.isFinite(catalogAmount) && orderAmount !== catalogAmount,
  }
}

async function submitPayment(req: Request, body: any) {
  const user = await authUser(req)
  const order = await getOrder(String(body.order_number || ''))
  if (!orderBelongsToUser(order, user)) {
    throw new Error('This order is not linked to the signed-in account. Please sign in with the same email used to create the order.')
  }
  if (String(order.status || '').toLowerCase() !== 'pending') throw new Error('This order is no longer pending payment approval')
  const plan = await getPlanSnapshot(order)
  const payment = body.payment && typeof body.payment === 'object' ? body.payment : {}
  if (!payment.date) throw new Error('Payment date is required')
  if (!payment.proof_path && !payment.proof_url) throw new Error('Payment proof is required')
  const payload = await updateOrderPayload(order, {
    method: String(payment.method || 'BANK_TRANSFER_KBANK'),
    date: String(payment.date),
    reference: String(payment.reference || ''),
    proof_path: String(payment.proof_path || ''),
    proof_url: String(payment.proof_url || ''),
    submitted_at: new Date().toISOString(),
    submitted_by: user.id,
  })

  let proofHref = String(payment.proof_url || '')
  if (payment.proof_path) {
    const signed = await admin!.storage.from(BUCKET).createSignedUrl(String(payment.proof_path), 7 * 24 * 60 * 60)
    if (!signed.error) proofHref = signed.data.signedUrl
  }
  const approveToken = await makeToken(order.order_number, 'approve')
  const rejectToken = await makeToken(order.order_number, 'reject')
  const approveUrl = `${APPROVAL_PAGE_URL}?approval=${encodeURIComponent(approveToken)}`
  const rejectUrl = `${APPROVAL_PAGE_URL}?approval=${encodeURIComponent(rejectToken)}`
  const billing = payload.billing || {}
  const subject = `KOL IDS · Payment approval required · ${order.order_number}`
  const htmlBody = `<div style="font-family:Arial,sans-serif;max-width:760px;color:#111"><h2 style="margin:0 0 8px">KOL IDS™ Payment Review</h2><p style="color:#666">A customer submitted a paid account application and payment proof.</p><table cellpadding="8" cellspacing="0" style="border-collapse:collapse;width:100%;font-size:14px"><tr><td><b>Order</b></td><td>${esc(order.order_number)}</td></tr><tr><td><b>Customer</b></td><td>${esc(order.customer_email || user.email)}</td></tr><tr><td><b>Name</b></td><td>${esc(user.user_metadata?.name || '')}</td></tr><tr><td><b>Organization</b></td><td>${esc(order.organization_name || payload.organization_name || '·')}</td></tr><tr><td><b>Plan</b></td><td>${esc(plan.name)} <span style="color:#777">(${esc(plan.code)})</span></td></tr><tr><td><b>Amount</b></td><td>THB ${esc(money(plan.priceThb))}</td></tr><tr><td><b>Duration</b></td><td>${esc(plan.durationDays)} days</td></tr>${plan.priceMismatch?`<tr><td><b>Price check</b></td><td style="color:#a15c00"><b>Stored order price differs from current catalog price.</b> Current catalog: THB ${esc(money(plan.catalogPriceThb))}. Review the original order amount before approval.</td></tr>`:''}<tr><td><b>Payment method</b></td><td>${esc(payment.method || '·')}</td></tr><tr><td><b>Payment date</b></td><td>${esc(payment.date || '·')}</td></tr><tr><td><b>Reference</b></td><td>${esc(payment.reference || '·')}</td></tr><tr><td><b>Proof</b></td><td>${proofHref ? `<a href="${esc(proofHref)}" target="_blank">Open payment proof</a>` : '·'}</td></tr><tr><td><b>Billing name</b></td><td>${esc(billing.legalName || '·')}</td></tr><tr><td><b>Billing phone</b></td><td>${esc(billing.phone || '·')}</td></tr></table><div style="margin:24px 0"><a href="${esc(approveUrl)}" style="display:inline-block;background:#111;color:#fff;text-decoration:none;padding:14px 22px;border-radius:8px;font-weight:700;margin-right:8px">REVIEW & APPROVE</a><a href="${esc(rejectUrl)}" style="display:inline-block;background:#fff;color:#111;text-decoration:none;padding:13px 21px;border:1px solid #bbb;border-radius:8px;font-weight:700">REJECT</a></div><p style="font-size:12px;color:#888">The approval link expires after 24 hours. Opening the link only shows the review page; the account changes state only after an explicit confirmation.</p></div>`
  const textBody = `KOL IDS Payment Review\nOrder: ${order.order_number}\nCustomer: ${order.customer_email || user.email}\nPlan: ${plan.name} (${plan.code})\nAmount: THB ${money(plan.priceThb)}\nDuration: ${plan.durationDays} days\n${plan.priceMismatch?`PRICE CHECK: stored order amount differs from current catalog price THB ${money(plan.catalogPriceThb)}. Review the original order amount.`:''}\nPayment method: ${payment.method || '·'}\nPayment date: ${payment.date || '·'}\nReference: ${payment.reference || '·'}\nProof: ${proofHref || '·'}\nApprove: ${approveUrl}\nReject: ${rejectUrl}`
  await sendEmail(ADMIN_EMAILS, subject, htmlBody, textBody)
  const customerEmail=String(order.customer_email || user.email || '').trim()
  if(customerEmail){
    const customerSubject=`KOL IDS · Application received · ${order.order_number}`
    const customerHtml=`<div style="font-family:Arial,sans-serif;max-width:680px;color:#111"><h2 style="margin:0 0 8px">Thank you for your KOL IDS™ application.</h2><p>We received your account application and payment proof for order <b>${esc(order.order_number)}</b>.</p><table cellpadding=7 cellspacing=0 style="border-collapse:collapse;width:100%;font-size:14px;margin:18px 0"><tr><td><b>Plan</b></td><td>${esc(plan.name)}</td></tr><tr><td><b>Amount</b></td><td>THB ${esc(money(plan.priceThb))}</td></tr><tr><td><b>Duration</b></td><td>${esc(plan.durationDays)} days</td></tr></table><p>Your order is now <b>pending payment verification</b>. We will email you again when the account is approved and active.</p><p style="margin-top:24px;color:#666;font-size:13px">You do not need to submit the payment proof again unless our team contacts you.</p><p style="font-size:12px;color:#888">KOL IDS™ · Creator Decision Intelligence</p></div>`
    const customerText=`Thank you for your KOL IDS application. Order ${order.order_number}. Plan: ${plan.name}. Amount: THB ${money(plan.priceThb)}. Duration: ${plan.durationDays} days. Your order is pending payment verification. We will email you again when the account is approved and active.`
    await sendEmail(customerEmail, customerSubject, customerHtml, customerText)
  }
  return json({ ok: true, order_number: order.order_number })
}

async function approveOrReject(parsed: { order_number: string, action: 'approve'|'reject' }) {
  const order = await getOrder(parsed.order_number)
  const endpoint = `${SUPABASE_URL}/functions/v1/payment-approval`
  const r = await fetch(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-kol-ids-approval-secret': PAYMENT_APPROVAL_SECRET }, body: JSON.stringify({ order_number: parsed.order_number, action: parsed.action }) })
  const raw = await r.text()
  let result: any = {}
  try { result = raw ? JSON.parse(raw) : {} } catch { result = { raw } }
  if (!r.ok || result.error) throw new Error(result.error || `Payment approval service failed (${r.status})`)
  return { order, result }
}

async function approvalPage(token: string) {
  const parsed = await readToken(token)
  const order = await getOrder(parsed.order_number)
  const actionLabel = parsed.action === 'approve' ? 'Approve this account' : 'Reject this application'
  const accent = parsed.action === 'approve' ? '#111' : '#8a2634'
  return html(`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>KOL IDS™ · ${actionLabel}</title><style>body{margin:0;background:#f5f6f7;color:#111;font-family:Arial,sans-serif}.wrap{max-width:720px;margin:60px auto;padding:28px}.card{background:#fff;border:1px solid #ddd;border-radius:18px;padding:28px;box-shadow:0 20px 60px rgba(0,0,0,.08)}h1{margin:0 0 8px}p{color:#666;line-height:1.55}.grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:22px 0}.cell{border:1px solid #eee;border-radius:10px;padding:12px}.cell span{display:block;color:#888;font-size:11px;margin-bottom:5px}.cell b{font-size:14px}.actions{display:flex;gap:10px;margin-top:22px}button{border:0;border-radius:10px;padding:13px 18px;font-weight:800;cursor:pointer;background:${accent};color:#fff}button.secondary{background:#fff;color:#111;border:1px solid #ccc}@media(max-width:600px){.wrap{margin:20px auto;padding:15px}.grid{grid-template-columns:1fr}.actions{flex-direction:column}}</style></head><body><div class="wrap"><div class="card"><div style="font-size:11px;letter-spacing:.14em;color:#777;font-weight:800">KOL IDS™ · ACCOUNT REVIEW</div><h1>${actionLabel}</h1><p>This is a secure review page for order <b>${esc(order.order_number)}</b>. The email link has not changed the account state.</p><div class="grid"><div class="cell"><span>Customer</span><b>${esc(order.customer_email || '·')}</b></div><div class="cell"><span>Plan</span><b>${esc(order.plan_code || '·')}</b></div><div class="cell"><span>Amount</span><b>THB ${esc(money(order.amount_thb))}</b></div><div class="cell"><span>Status</span><b>${esc(order.status || 'pending')}</b></div></div><form method="post"><input type="hidden" name="approval" value="${esc(token)}"><button type="submit">CONFIRM ${parsed.action.toUpperCase()}</button><a href="${SUPABASE_URL}/functions/v1/signup-approval" style="display:inline-block;margin-left:10px;padding:12px 16px;color:#666;text-decoration:none">Cancel</a></form></div></div></body></html>`)
}

async function handle(req: Request) {
  requireConfig()
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  const url = new URL(req.url)
  if (req.method === 'GET') {
    const token = url.searchParams.get('approval') || ''
    if (!token) return new Response(null, { status: 302, headers: { Location: APPROVAL_PAGE_URL } })
    return new Response(null, { status: 302, headers: { Location: `${APPROVAL_PAGE_URL}?approval=${encodeURIComponent(token)}` } })
  }
  if (req.method !== 'POST') return json({ ok: false, error: 'Method not allowed' }, 405)
  const body = await req.json()
  if (body.approval) {
    const parsed = await readToken(String(body.approval))
    const { order, result } = await approveOrReject(parsed)
    return json({ ok: true, action: parsed.action, order_number: order.order_number, customer_email: order.customer_email || '', result })
  }
  if (body.action === 'prepare_upload') return prepareUpload(req, body)
  if (body.action === 'submit_payment') return submitPayment(req, body)
  return json({ ok: false, error: 'Unknown action' }, 400)
}

Deno.serve(async req => {
  try { return await handle(req) } catch (err) {
    console.error(err)
    const message = err instanceof Error ? err.message : 'Unexpected error'
    if (req.method === 'GET') return html(`<div style="font-family:Arial,sans-serif;max-width:680px;margin:70px auto;padding:28px;border:1px solid #ddd;border-radius:16px;background:#fff"><h1>Account review could not be completed</h1><p>${esc(message)}</p></div>`, 400)
    return json({ ok: false, error: message }, 400)
  }
})
