-- KOL IDS V30.1 commercial + low-friction intake hardening

insert into public.plans(code,name,duration_days,price_thb,seats,is_trial)
values
('PLAN_3M','3 Months',90,29900,1,false),
('PLAN_6M','6 Months',180,55900,2,false),
('PLAN_12M','12 Months',365,105900,3,false)
on conflict (code) do update set price_thb=excluded.price_thb,updated_at=now();
