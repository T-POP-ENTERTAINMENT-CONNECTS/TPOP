-- KOL IDS: fix legacy creators.kol_code NOT NULL contract
-- Safe for existing rows; generates a stable-looking internal creator code.
alter table public.creators
  add column if not exists kol_code text;

update public.creators
set kol_code = 'KOL-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 12))
where kol_code is null;

alter table public.creators
  alter column kol_code set default ('KOL-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 12))),
  alter column kol_code set not null;

create unique index if not exists creators_kol_code_unique on public.creators(kol_code);
