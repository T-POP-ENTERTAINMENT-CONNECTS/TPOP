-- KOL IDS paid-upgrade production hardening
-- Ensures paid plans exist and refreshes the existing-account upgrade RPC.
-- Safe to run after 20261004_existing_account_paid_upgrade.sql.

insert into public.plans(code,name,duration_days,price_thb,seats,is_trial,active)
values
  ('TRIAL_7','7-Day Trial',7,0,1,true,true),
  ('PLAN_3M','3 Months',90,29900,1,false,true),
  ('PLAN_6M','6 Months',180,55900,2,false,true),
  ('PLAN_12M','12 Months',365,105900,3,false,true)
on conflict (code) do update set
  name=excluded.name,
  duration_days=excluded.duration_days,
  price_thb=excluded.price_thb,
  seats=excluded.seats,
  is_trial=excluded.is_trial,
  active=true,
  updated_at=now();

-- Refresh the canonical function from the existing-account upgrade migration.
-- The pending-order query uses only values allowed by customer_orders.payment_status.
drop function if exists public.provision_customer_account(uuid,text,text,text,text);
create or replace function public.provision_customer_account(
  p_user_id uuid,
  p_email text,
  p_name text,
  p_plan_code text,
  p_organization_name text default null,
  p_billing jsonb default '{}'::jsonb
)
returns jsonb
language plpgsql security definer
set search_path = ''
as $$
declare
  v_plan public.plans;
  v_org public.organizations;
  v_membership public.organization_memberships;
  v_sub public.subscriptions;
  v_order public.customer_orders;
  v_email text := lower(trim(p_email));
  v_org_name text := coalesce(nullif(trim(p_organization_name),''), split_part(v_email,'@',1) || ' Organization');
  v_order_no text;
begin
  if p_user_id is null or v_email='' then raise exception 'Invalid customer identity'; end if;
  select * into v_plan from public.plans where code=p_plan_code and active=true;
  if v_plan.code is null then raise exception 'Unknown or inactive plan'; end if;

  insert into public.profiles(user_id,email,display_name,company_name)
  values(p_user_id,v_email,nullif(trim(p_name),''),nullif(trim(p_organization_name),''))
  on conflict(user_id) do update set email=excluded.email,display_name=coalesce(excluded.display_name,public.profiles.display_name),company_name=coalesce(excluded.company_name,public.profiles.company_name),updated_at=now();

  select o.* into v_org
  from public.organizations o
  join public.organization_memberships m on m.organization_id=o.id
  where m.user_id=p_user_id and m.status='active'
  order by o.created_at asc limit 1;

  if v_org.id is null then
    insert into public.organizations(name,created_by,slug)
    values(v_org_name,p_user_id,regexp_replace(lower(v_org_name),'[^a-z0-9]+','-','g') || '-' || substr(replace(gen_random_uuid()::text,'-',''),1,8))
    returning * into v_org;
    insert into public.organization_memberships(organization_id,user_id,role,status)
    values(v_org.id,p_user_id,'owner','active') returning * into v_membership;
  else
    select * into v_membership from public.organization_memberships where organization_id=v_org.id and user_id=p_user_id;
  end if;

  if v_plan.is_trial then
    if exists(select 1 from public.trial_redemptions where lower(email)=v_email) then
      raise exception 'Trial already used for this email';
    end if;
    insert into public.subscriptions(organization_id,plan_code,status,starts_at,expires_at)
    values(v_org.id,v_plan.code,'active',now(),now() + make_interval(days=>v_plan.duration_days))
    returning * into v_sub;
    insert into public.trial_redemptions(user_id,email,organization_id,subscription_id)
    values(p_user_id,v_email,v_org.id,v_sub.id);
    insert into public.subscription_events(subscription_id,organization_id,event_type,actor_user_id,payload)
    values(v_sub.id,v_org.id,'trial_activated',p_user_id,jsonb_build_object('plan',v_plan.code));
  else
    select co.* into v_order
    from public.customer_orders co
    where co.organization_id=v_org.id
      and co.requested_by=p_user_id
      and co.plan_code=v_plan.code
      and co.status='pending'
      and co.payment_status in ('unpaid','pending')
    order by co.created_at desc limit 1;

    if v_order.id is not null then
      select * into v_sub from public.subscriptions where order_id=v_order.id order by created_at desc limit 1;
      if v_sub.id is null then
        insert into public.subscriptions(organization_id,plan_code,order_id,status,starts_at,expires_at)
        values(v_org.id,v_plan.code,v_order.id,'pending',now(),null) returning * into v_sub;
      end if;
      update public.customer_orders
      set customer_email=v_email,amount_thb=coalesce(amount_thb,v_plan.price_thb),
          payload=coalesce(payload,'{}'::jsonb) || jsonb_build_object('billing',coalesce(p_billing,'{}'::jsonb),'source','existing_order_resume'),
          updated_at=now() where id=v_order.id;
      select * into v_order from public.customer_orders where id=v_order.id;
    else
      v_order_no := 'KID-' || to_char(now(),'YYYYMMDDHH24MISS') || '-' || upper(substr(replace(gen_random_uuid()::text,'-',''),1,6));
      insert into public.customer_orders(order_number,organization_id,requested_by,plan_code,status,payment_status,amount_thb,customer_email,payload)
      values(v_order_no,v_org.id,p_user_id,v_plan.code,'pending','unpaid',v_plan.price_thb,v_email,jsonb_build_object('source','customer_signup','billing',coalesce(p_billing,'{}'::jsonb)))
      returning * into v_order;
      insert into public.subscriptions(organization_id,plan_code,order_id,status,starts_at,expires_at)
      values(v_org.id,v_plan.code,v_order.id,'pending',now(),null) returning * into v_sub;
      insert into public.subscription_events(subscription_id,organization_id,order_id,event_type,actor_user_id,payload)
      values(v_sub.id,v_org.id,v_order.id,'order_created',p_user_id,jsonb_build_object('order_number',v_order.order_number,'plan',v_plan.code));
    end if;
  end if;

  return jsonb_build_object(
    'user_id',p_user_id,'organization',to_jsonb(v_org),'membership',to_jsonb(v_membership),
    'subscription',to_jsonb(v_sub),'plan',to_jsonb(v_plan),
    'order',case when v_order.id is null then null else to_jsonb(v_order) end,
    'access_granted',v_plan.is_trial,
    'message',case when v_plan.is_trial then 'Trial activated' else 'Account created; payment approval is required before workspace access' end
  );
end;
$$;
revoke all on function public.provision_customer_account(uuid,text,text,text,text,jsonb) from public,anon,authenticated;
grant execute on function public.provision_customer_account(uuid,text,text,text,text,jsonb) to service_role;
notify pgrst, 'reload schema';
