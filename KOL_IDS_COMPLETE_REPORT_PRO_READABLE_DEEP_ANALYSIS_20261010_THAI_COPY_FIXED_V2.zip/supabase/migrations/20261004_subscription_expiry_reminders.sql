-- KOL IDS subscription expiry reminders
-- Trial: one email in the 2–3 day window before expiry.
-- Paid plans: one email in the 29–30 day window before expiry.
-- The notification log prevents duplicate sends for the same subscription/reminder type.

create table if not exists public.subscription_expiry_notifications (
  id uuid primary key default gen_random_uuid(),
  subscription_id uuid not null references public.subscriptions(id) on delete cascade,
  reminder_code text not null check (reminder_code in ('TRIAL_3_DAYS','PAID_30_DAYS')),
  status text not null default 'sending' check (status in ('sending','sent','failed')),
  attempted_at timestamptz not null default now(),
  sent_at timestamptz,
  error_message text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(subscription_id, reminder_code)
);

create index if not exists subscription_expiry_notifications_subscription_idx
  on public.subscription_expiry_notifications(subscription_id, reminder_code, status);

alter table public.subscription_expiry_notifications enable row level security;

-- No customer-facing read/write access. The reminder Edge Function uses the service role.
drop policy if exists subscription_expiry_notifications_no_client_access on public.subscription_expiry_notifications;
create policy subscription_expiry_notifications_no_client_access
  on public.subscription_expiry_notifications
  for all to authenticated
  using (false)
  with check (false);

revoke all on public.subscription_expiry_notifications from anon, authenticated;

grant select, insert, update on public.subscription_expiry_notifications to service_role;

notify pgrst, 'reload schema';
