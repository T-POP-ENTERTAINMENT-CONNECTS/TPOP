-- KOL IDS™ Campaign payload compatibility repair
-- Fixes workspaces created from an older campaigns table that lacks payload.
-- Safe to run repeatedly; no existing data is dropped.

alter table public.campaigns add column if not exists payload jsonb default '{}'::jsonb;
alter table public.campaigns add column if not exists updated_at timestamptz not null default now();
alter table public.audiences add column if not exists payload jsonb default '{}'::jsonb;
alter table public.creators add column if not exists payload jsonb default '{}'::jsonb;
alter table public.review_runs add column if not exists payload jsonb default '{}'::jsonb;
alter table public.generated_impacts add column if not exists payload jsonb default '{}'::jsonb;
alter table public.reports_evidence add column if not exists payload jsonb default '{}'::jsonb;

notify pgrst, 'reload schema';
