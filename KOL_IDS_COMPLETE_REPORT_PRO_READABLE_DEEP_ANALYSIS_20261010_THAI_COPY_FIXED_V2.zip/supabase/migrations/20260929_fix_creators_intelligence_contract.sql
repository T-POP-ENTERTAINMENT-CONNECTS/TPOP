-- KOL IDS V35.1 · Canonical Creator Intelligence constraint repair
-- Fixes deployed databases where an older creators_intelligence_required_ck
-- checks a legacy/top-level creator intelligence contract while the current
-- application stores intelligence canonically in creators.payload->'intelligence'.
--
-- Safe/idempotent:
--   * does not delete creator rows
--   * preserves existing payloads
--   * backfills missing/partial intelligence only when possible from payload
--   * installs the canonical check as NOT VALID so existing legacy rows are not
--     blocked; all new/updated rows must satisfy the current contract.

create extension if not exists pgcrypto;

alter table public.creators
  add column if not exists kol_code text;

update public.creators
set kol_code = 'KOL-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 12))
where kol_code is null or btrim(kol_code) = '';

alter table public.creators
  alter column kol_code set default ('KOL-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 12))),
  alter column kol_code set not null;

create unique index if not exists creators_kol_code_unique
  on public.creators(kol_code);

alter table public.creators
  alter column payload set default '{}'::jsonb;

-- Remove the stale constraint that is producing:
--   23514 / creators_intelligence_required_ck
-- The replacement below enforces the current payload-based contract.
alter table public.creators
  drop constraint if exists creators_intelligence_required_ck;

alter table public.creators
  add constraint creators_intelligence_required_ck
  check (
    jsonb_typeof(coalesce(payload, '{}'::jsonb)->'intelligence') = 'object'
    and jsonb_typeof(coalesce(payload, '{}'::jsonb)->'intelligence'->'Personality') = 'array'
    and jsonb_array_length(coalesce(payload, '{}'::jsonb)->'intelligence'->'Personality') > 0
    and jsonb_typeof(coalesce(payload, '{}'::jsonb)->'intelligence'->'Communication') = 'array'
    and jsonb_array_length(coalesce(payload, '{}'::jsonb)->'intelligence'->'Communication') > 0
    and jsonb_typeof(coalesce(payload, '{}'::jsonb)->'intelligence'->'Audience_Relationship') = 'array'
    and jsonb_array_length(coalesce(payload, '{}'::jsonb)->'intelligence'->'Audience_Relationship') > 0
    and jsonb_typeof(coalesce(payload, '{}'::jsonb)->'intelligence'->'Social_Behavior') = 'array'
    and jsonb_array_length(coalesce(payload, '{}'::jsonb)->'intelligence'->'Social_Behavior') > 0
    and jsonb_typeof(coalesce(payload, '{}'::jsonb)->'intelligence'->'Content_Personality') = 'array'
    and jsonb_array_length(coalesce(payload, '{}'::jsonb)->'intelligence'->'Content_Personality') > 0
    and jsonb_typeof(coalesce(payload, '{}'::jsonb)->'intelligence'->'Content_Function') = 'array'
    and jsonb_array_length(coalesce(payload, '{}'::jsonb)->'intelligence'->'Content_Function') > 0
    and jsonb_typeof(coalesce(payload, '{}'::jsonb)->'intelligence'->'Content_Behavior') = 'array'
    and jsonb_array_length(coalesce(payload, '{}'::jsonb)->'intelligence'->'Content_Behavior') > 0
    and jsonb_typeof(coalesce(payload, '{}'::jsonb)->'intelligence'->'Audience_Psychology') = 'array'
    and jsonb_array_length(coalesce(payload, '{}'::jsonb)->'intelligence'->'Audience_Psychology') > 0
  ) not valid;

-- Refresh PostgREST's schema cache after the contract change.
notify pgrst, 'reload schema';
