-- KOL IDS™ Frontend ↔ Supabase Database Contract Alignment
-- Date: 2026-09-26
-- Purpose: make the live database match the current 7-step GitHub frontend contract.
-- Safe/idempotent: does not drop product data.
-- IMPORTANT: run this AFTER supabase/schema.sql and the intelligence-engine migration.

create extension if not exists pgcrypto;

-- ============================================================
-- 0. LEGACY CAMPAIGN COLUMN COMPATIBILITY
-- ============================================================
-- Older workspaces may still have campaigns.brand_id defined as NOT NULL.
-- The current frontend stores brand intelligence inside payload and does not
-- send a top-level brand_id. Keep the legacy column, when present, but make it
-- optional so campaign inserts cannot fail with a NOT NULL violation.
do $$
begin
  if exists (
    select 1
    from information_schema.columns
    where table_schema='public'
      and table_name='campaigns'
      and column_name='brand_id'
  ) then
    execute 'alter table public.campaigns alter column brand_id drop not null';
  end if;
end $$;

-- ============================================================
-- 1. CORE FRONTEND TABLE CONTRACT
-- ============================================================

alter table public.campaigns
  add column if not exists organization_id uuid,
  add column if not exists name text,
  add column if not exists status text default 'draft',
  add column if not exists payload jsonb default '{}'::jsonb,
  add column if not exists created_by uuid,
  add column if not exists created_at timestamptz default now(),
  add column if not exists updated_at timestamptz default now();

-- The current frontend creates a shell campaign from Step 02 without sending
-- created_by. Default it at DB level so that flow is valid and remains owned by
-- the authenticated user.
alter table public.campaigns
  alter column created_by set default auth.uid(),
  alter column payload set default '{}'::jsonb,
  alter column status set default 'draft',
  alter column created_at set default now(),
  alter column updated_at set default now();

alter table public.audiences
  add column if not exists organization_id uuid,
  add column if not exists campaign_id uuid,
  add column if not exists name text,
  add column if not exists payload jsonb default '{}'::jsonb,
  add column if not exists created_at timestamptz default now();

alter table public.creators
  add column if not exists kol_code text;

update public.creators
set kol_code = 'KOL-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 12))
where kol_code is null;

alter table public.creators
  alter column kol_code set default ('KOL-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 12))),
  alter column kol_code set not null;

alter table public.creators
  add column if not exists organization_id uuid,
  add column if not exists name text,
  add column if not exists payload jsonb default '{}'::jsonb,
  add column if not exists created_at timestamptz default now();

alter table public.creator_decisions
  add column if not exists organization_id uuid,
  add column if not exists campaign_id uuid,
  add column if not exists creator_id uuid,
  add column if not exists decision text,
  add column if not exists score numeric,
  add column if not exists evidence jsonb default '{}'::jsonb,
  add column if not exists created_by uuid,
  add column if not exists created_at timestamptz default now();

alter table public.review_runs
  add column if not exists organization_id uuid,
  add column if not exists campaign_id uuid,
  add column if not exists status text default 'draft',
  add column if not exists payload jsonb default '{}'::jsonb,
  add column if not exists created_by uuid,
  add column if not exists created_at timestamptz default now();

alter table public.generated_impacts
  add column if not exists organization_id uuid,
  add column if not exists campaign_id uuid,
  add column if not exists payload jsonb default '{}'::jsonb,
  add column if not exists created_at timestamptz default now();

alter table public.reports_evidence
  add column if not exists organization_id uuid,
  add column if not exists campaign_id uuid,
  add column if not exists payload jsonb default '{}'::jsonb,
  add column if not exists created_at timestamptz default now();

-- ============================================================
-- 2. REQUIRED FOREIGN KEYS / INDEXES
-- ============================================================

do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conname='campaigns_organization_id_fkey'
      and conrelid='public.campaigns'::regclass
  ) then
    alter table public.campaigns
      add constraint campaigns_organization_id_fkey
      foreign key (organization_id) references public.organizations(id) on delete cascade;
  end if;

  if not exists (
    select 1 from pg_constraint
    where conname='campaigns_created_by_fkey'
      and conrelid='public.campaigns'::regclass
  ) then
    alter table public.campaigns
      add constraint campaigns_created_by_fkey
      foreign key (created_by) references auth.users(id);
  end if;

  if not exists (
    select 1 from pg_constraint
    where conname='audiences_organization_id_fkey'
      and conrelid='public.audiences'::regclass
  ) then
    alter table public.audiences
      add constraint audiences_organization_id_fkey
      foreign key (organization_id) references public.organizations(id) on delete cascade;
  end if;

  if not exists (
    select 1 from pg_constraint
    where conname='audiences_campaign_id_fkey'
      and conrelid='public.audiences'::regclass
  ) then
    alter table public.audiences
      add constraint audiences_campaign_id_fkey
      foreign key (campaign_id) references public.campaigns(id) on delete cascade;
  end if;

  if not exists (
    select 1 from pg_constraint
    where conname='creators_organization_id_fkey'
      and conrelid='public.creators'::regclass
  ) then
    alter table public.creators
      add constraint creators_organization_id_fkey
      foreign key (organization_id) references public.organizations(id) on delete cascade;
  end if;
end $$;

create index if not exists campaigns_org_created_idx
  on public.campaigns(organization_id, created_at desc);
create index if not exists audiences_org_campaign_idx
  on public.audiences(organization_id, campaign_id, created_at desc);
create index if not exists creators_org_created_idx
  on public.creators(organization_id, created_at desc);
create index if not exists decisions_org_campaign_idx
  on public.creator_decisions(organization_id, campaign_id, created_at desc);
create index if not exists review_runs_org_campaign_idx
  on public.review_runs(organization_id, campaign_id, created_at desc);
create index if not exists impacts_org_campaign_idx
  on public.generated_impacts(organization_id, campaign_id, created_at desc);
create index if not exists evidence_org_campaign_idx
  on public.reports_evidence(organization_id, campaign_id, created_at desc);

-- ============================================================
-- 3. INTELLIGENCE ENGINE TABLES REQUIRED BY app.js
-- ============================================================

create table if not exists public.performance_observations (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  campaign_id uuid not null references public.campaigns(id) on delete cascade,
  creator_id uuid not null references public.creators(id) on delete cascade,
  observed_at timestamptz not null,
  status text not null default 'COMPLETED' check(status in ('COMPLETED','PARTIAL','INVALID')),
  source text not null default 'SELF-REPORTED',
  goal text,
  spend_thb numeric(14,2),
  revenue_thb numeric(14,2),
  reach numeric,
  impressions numeric,
  views numeric,
  likes numeric,
  comments numeric,
  shares numeric,
  clicks numeric,
  conversions numeric,
  engagement numeric,
  quality_score numeric,
  validation jsonb not null default '{}'::jsonb,
  metadata jsonb not null default '{}'::jsonb,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.prediction_ledger (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  campaign_id uuid not null references public.campaigns(id) on delete cascade,
  creator_id uuid not null references public.creators(id) on delete cascade,
  goal text not null,
  predicted_at timestamptz not null default now(),
  actual_at timestamptz,
  predicted_score numeric,
  lower_bound numeric,
  upper_bound numeric,
  actual_score numeric,
  covered boolean,
  model_version text not null default 'SUPABASE_INTELLIGENCE_V1',
  method text not null,
  evidence jsonb not null default '{}'::jsonb,
  created_by uuid references auth.users(id)
);

create table if not exists public.intelligence_runs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  campaign_id uuid references public.campaigns(id) on delete cascade,
  run_type text not null,
  model_version text not null,
  status text not null default 'COMPLETED',
  parameters jsonb not null default '{}'::jsonb,
  result jsonb not null default '{}'::jsonb,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create table if not exists public.portfolio_runs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  campaign_id uuid not null references public.campaigns(id) on delete cascade,
  budget_thb numeric(14,2) not null default 0,
  status text not null,
  portfolio_score numeric,
  confidence numeric,
  planned_spend numeric,
  budget_remaining numeric,
  risk_exposure numeric,
  coverage_score numeric,
  synergy_score numeric,
  objective text,
  result jsonb not null default '{}'::jsonb,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create table if not exists public.portfolio_items (
  id uuid primary key default gen_random_uuid(),
  portfolio_run_id uuid not null references public.portfolio_runs(id) on delete cascade,
  creator_id uuid not null references public.creators(id) on delete cascade,
  rank int not null,
  allocation_thb numeric(14,2) not null default 0,
  candidate_score numeric,
  objective_alignment numeric,
  impact_score numeric,
  confidence numeric,
  risk numeric,
  evidence_score numeric,
  selection_reason text,
  metadata jsonb not null default '{}'::jsonb
);

alter table public.performance_observations
  add column if not exists updated_at timestamptz not null default now();

create index if not exists performance_obs_org_creator_date_idx
  on public.performance_observations(organization_id,creator_id,observed_at desc);
create index if not exists performance_obs_org_campaign_date_idx
  on public.performance_observations(organization_id,campaign_id,observed_at desc);
create index if not exists prediction_ledger_org_goal_date_idx
  on public.prediction_ledger(organization_id,goal,predicted_at desc);
create index if not exists intelligence_runs_org_created_idx
  on public.intelligence_runs(organization_id,created_at desc);
create index if not exists portfolio_runs_org_campaign_idx
  on public.portfolio_runs(organization_id,campaign_id,created_at desc);
create index if not exists portfolio_items_run_rank_idx
  on public.portfolio_items(portfolio_run_id,rank);

-- ============================================================
-- 4. ORGANIZATION-SAFE CHILD RECORDS
-- ============================================================
-- Prevent the frontend from accidentally attaching a child record to a
-- different organization than its campaign/creator.

create or replace function public.kolids_validate_org_links()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_campaign_org uuid;
  v_creator_org uuid;
  v_run_org uuid;
begin
  if tg_table_name = 'audiences' and new.campaign_id is not null then
    select organization_id into v_campaign_org from public.campaigns where id=new.campaign_id;
    if v_campaign_org is not null and new.organization_id <> v_campaign_org then
      raise exception 'ORG_LINK_MISMATCH: audience organization does not match campaign organization';
    end if;
  elsif tg_table_name = 'creator_decisions' then
    if new.campaign_id is not null then
      select organization_id into v_campaign_org from public.campaigns where id=new.campaign_id;
      if v_campaign_org is not null and new.organization_id <> v_campaign_org then
        raise exception 'ORG_LINK_MISMATCH: decision organization does not match campaign organization';
      end if;
    end if;
    if new.creator_id is not null then
      select organization_id into v_creator_org from public.creators where id=new.creator_id;
      if v_creator_org is not null and new.organization_id <> v_creator_org then
        raise exception 'ORG_LINK_MISMATCH: decision organization does not match creator organization';
      end if;
    end if;
  elsif tg_table_name in ('review_runs','generated_impacts','reports_evidence','performance_observations','prediction_ledger','intelligence_runs','portfolio_runs') then
    if new.campaign_id is not null then
      select organization_id into v_campaign_org from public.campaigns where id=new.campaign_id;
      if v_campaign_org is not null and new.organization_id <> v_campaign_org then
        raise exception 'ORG_LINK_MISMATCH: record organization does not match campaign organization';
      end if;
    end if;
    if tg_table_name in ('performance_observations','prediction_ledger') and new.creator_id is not null then
      select organization_id into v_creator_org from public.creators where id=new.creator_id;
      if v_creator_org is not null and new.organization_id <> v_creator_org then
        raise exception 'ORG_LINK_MISMATCH: performance organization does not match creator organization';
      end if;
    end if;
  elsif tg_table_name = 'portfolio_items' then
    select r.organization_id into v_run_org
      from public.portfolio_runs r where r.id=new.portfolio_run_id;
    select c.organization_id into v_creator_org
      from public.creators c where c.id=new.creator_id;
    if v_run_org is not null and v_creator_org is not null and v_run_org <> v_creator_org then
      raise exception 'ORG_LINK_MISMATCH: portfolio item organization does not match creator organization';
    end if;
  end if;
  return new;
end;
$$;

do $$
begin
  if not exists (select 1 from pg_trigger where tgname='kolids_audience_org_guard') then
    create trigger kolids_audience_org_guard before insert or update on public.audiences
    for each row execute function public.kolids_validate_org_links();
  end if;
  if not exists (select 1 from pg_trigger where tgname='kolids_decision_org_guard') then
    create trigger kolids_decision_org_guard before insert or update on public.creator_decisions
    for each row execute function public.kolids_validate_org_links();
  end if;
  if not exists (select 1 from pg_trigger where tgname='kolids_review_org_guard') then
    create trigger kolids_review_org_guard before insert or update on public.review_runs
    for each row execute function public.kolids_validate_org_links();
  end if;
  if not exists (select 1 from pg_trigger where tgname='kolids_impact_org_guard') then
    create trigger kolids_impact_org_guard before insert or update on public.generated_impacts
    for each row execute function public.kolids_validate_org_links();
  end if;
  if not exists (select 1 from pg_trigger where tgname='kolids_evidence_org_guard') then
    create trigger kolids_evidence_org_guard before insert or update on public.reports_evidence
    for each row execute function public.kolids_validate_org_links();
  end if;
  if not exists (select 1 from pg_trigger where tgname='kolids_performance_org_guard') then
    create trigger kolids_performance_org_guard before insert or update on public.performance_observations
    for each row execute function public.kolids_validate_org_links();
  end if;
  if not exists (select 1 from pg_trigger where tgname='kolids_prediction_org_guard') then
    create trigger kolids_prediction_org_guard before insert or update on public.prediction_ledger
    for each row execute function public.kolids_validate_org_links();
  end if;
  if not exists (select 1 from pg_trigger where tgname='kolids_intelligence_org_guard') then
    create trigger kolids_intelligence_org_guard before insert or update on public.intelligence_runs
    for each row execute function public.kolids_validate_org_links();
  end if;
  if not exists (select 1 from pg_trigger where tgname='kolids_portfolio_org_guard') then
    create trigger kolids_portfolio_org_guard before insert or update on public.portfolio_runs
    for each row execute function public.kolids_validate_org_links();
  end if;
  if not exists (select 1 from pg_trigger where tgname='kolids_portfolio_item_org_guard') then
    create trigger kolids_portfolio_item_org_guard before insert or update on public.portfolio_items
    for each row execute function public.kolids_validate_org_links();
  end if;
end $$;

-- ============================================================
-- 5. REMOVE OBSOLETE LEGACY BRAND VALIDATION FROM CAMPAIGNS
-- ============================================================
-- The current GitHub frontend stores brand intelligence inside
-- campaigns.payload and has no brands table/brand_id contract.
-- If an older deployment left a campaign trigger that throws
-- BRAND_ORG_MISMATCH, it is incompatible with the current frontend.
-- Remove only triggers whose function definition explicitly contains
-- that obsolete error token. No product rows are deleted.

do $$
declare
  r record;
begin
  for r in
    select t.tgname
    from pg_trigger t
    join pg_class c on c.oid=t.tgrelid
    join pg_namespace n on n.oid=c.relnamespace
    join pg_proc p on p.oid=t.tgfoid
    where n.nspname='public'
      and c.relname='campaigns'
      and not t.tgisinternal
      and pg_get_functiondef(p.oid) ilike '%BRAND_ORG_MISMATCH%'
  loop
    execute format('drop trigger if exists %I on public.campaigns', r.tgname);
  end loop;
end $$;

-- ============================================================
-- 6. RLS FOR CURRENT FRONTEND CONTRACT
-- ============================================================

alter table public.campaigns enable row level security;
alter table public.audiences enable row level security;
alter table public.creators enable row level security;
alter table public.creator_decisions enable row level security;
alter table public.review_runs enable row level security;
alter table public.generated_impacts enable row level security;
alter table public.reports_evidence enable row level security;
alter table public.performance_observations enable row level security;
alter table public.prediction_ledger enable row level security;
alter table public.intelligence_runs enable row level security;
alter table public.portfolio_runs enable row level security;
alter table public.portfolio_items enable row level security;

-- Replace only the product/intelligence policies. Commercial tables remain
-- governed by the production schema and Edge Functions.
do $$
declare r record;
begin
  for r in
    select policyname, tablename
    from pg_policies
    where schemaname='public'
      and tablename in (
        'campaigns','audiences','creators','creator_decisions','review_runs',
        'generated_impacts','reports_evidence','performance_observations',
        'prediction_ledger','intelligence_runs','portfolio_runs','portfolio_items'
      )
  loop
    execute format('drop policy if exists %I on public.%I',r.policyname,r.tablename);
  end loop;
end $$;

create policy campaign_select on public.campaigns
  for select to authenticated
  using (public.is_org_member(organization_id));
create policy campaign_insert on public.campaigns
  for insert to authenticated
  with check (
    public.is_org_member(organization_id)
    and public.has_active_subscription(organization_id)
    and created_by=auth.uid()
  );
create policy campaign_update on public.campaigns
  for update to authenticated
  using (public.is_org_member(organization_id) and public.has_active_subscription(organization_id))
  with check (public.is_org_member(organization_id) and public.has_active_subscription(organization_id));
create policy campaign_delete on public.campaigns
  for delete to authenticated
  using (public.is_org_member(organization_id) and public.has_active_subscription(organization_id));

create policy audience_select on public.audiences
  for select to authenticated using (public.is_org_member(organization_id));
create policy audience_insert on public.audiences
  for insert to authenticated
  with check (public.is_org_member(organization_id) and public.has_active_subscription(organization_id));
create policy audience_update on public.audiences
  for update to authenticated
  using (public.is_org_member(organization_id) and public.has_active_subscription(organization_id))
  with check (public.is_org_member(organization_id) and public.has_active_subscription(organization_id));
create policy audience_delete on public.audiences
  for delete to authenticated using (public.is_org_member(organization_id) and public.has_active_subscription(organization_id));

create policy creator_select on public.creators
  for select to authenticated using (public.is_org_member(organization_id));
create policy creator_insert on public.creators
  for insert to authenticated
  with check (public.is_org_member(organization_id) and public.has_active_subscription(organization_id));
create policy creator_update on public.creators
  for update to authenticated
  using (public.is_org_member(organization_id) and public.has_active_subscription(organization_id))
  with check (public.is_org_member(organization_id) and public.has_active_subscription(organization_id));
create policy creator_delete on public.creators
  for delete to authenticated using (public.is_org_member(organization_id) and public.has_active_subscription(organization_id));

create policy decision_select on public.creator_decisions
  for select to authenticated using (public.is_org_member(organization_id));
create policy decision_insert on public.creator_decisions
  for insert to authenticated
  with check (public.is_org_member(organization_id) and public.has_active_subscription(organization_id) and created_by=auth.uid());
create policy decision_update on public.creator_decisions
  for update to authenticated
  using (public.is_org_member(organization_id) and public.has_active_subscription(organization_id))
  with check (public.is_org_member(organization_id) and public.has_active_subscription(organization_id));
create policy decision_delete on public.creator_decisions
  for delete to authenticated using (public.is_org_member(organization_id) and public.has_active_subscription(organization_id));

create policy review_select on public.review_runs
  for select to authenticated using (public.is_org_member(organization_id));
create policy review_insert on public.review_runs
  for insert to authenticated
  with check (public.is_org_member(organization_id) and public.has_active_subscription(organization_id) and created_by=auth.uid());

create policy impact_select on public.generated_impacts
  for select to authenticated using (public.is_org_member(organization_id));
create policy impact_insert on public.generated_impacts
  for insert to authenticated
  with check (public.is_org_member(organization_id) and public.has_active_subscription(organization_id));

create policy evidence_select on public.reports_evidence
  for select to authenticated using (public.is_org_member(organization_id));
create policy evidence_insert on public.reports_evidence
  for insert to authenticated
  with check (public.is_org_member(organization_id) and public.has_active_subscription(organization_id));

create policy performance_select on public.performance_observations
  for select to authenticated using (public.is_org_member(organization_id));
create policy performance_write on public.performance_observations
  for all to authenticated
  using (public.is_org_member(organization_id) and public.has_active_subscription(organization_id))
  with check (public.is_org_member(organization_id) and public.has_active_subscription(organization_id));

create policy prediction_select on public.prediction_ledger
  for select to authenticated using (public.is_org_member(organization_id));
create policy prediction_write on public.prediction_ledger
  for all to authenticated
  using (public.is_org_member(organization_id) and public.has_active_subscription(organization_id))
  with check (public.is_org_member(organization_id) and public.has_active_subscription(organization_id));

create policy intelligence_select on public.intelligence_runs
  for select to authenticated using (public.is_org_member(organization_id));
create policy intelligence_insert on public.intelligence_runs
  for insert to authenticated
  with check (public.is_org_member(organization_id) and public.has_active_subscription(organization_id) and created_by=auth.uid());

create policy portfolio_select on public.portfolio_runs
  for select to authenticated using (public.is_org_member(organization_id));
create policy portfolio_insert on public.portfolio_runs
  for insert to authenticated
  with check (public.is_org_member(organization_id) and public.has_active_subscription(organization_id) and created_by=auth.uid());

create policy portfolio_item_select on public.portfolio_items
  for select to authenticated
  using (exists(
    select 1 from public.portfolio_runs r
    where r.id=portfolio_items.portfolio_run_id
      and public.is_org_member(r.organization_id)
  ));
create policy portfolio_item_insert on public.portfolio_items
  for insert to authenticated
  with check (exists(
    select 1 from public.portfolio_runs r
    where r.id=portfolio_items.portfolio_run_id
      and public.is_org_member(r.organization_id)
      and public.has_active_subscription(r.organization_id)
  ));

-- ============================================================
-- 7. POSTGREST SCHEMA CACHE
-- ============================================================
notify pgrst, 'reload schema';

-- ============================================================
-- 8. FINAL CONTRACT CHECK
-- ============================================================
select
  'KOL_IDS_FRONTEND_CONTRACT' as check_name,
  exists(select 1 from information_schema.columns where table_schema='public' and table_name='campaigns' and column_name='organization_id') as campaigns_org,
  exists(select 1 from information_schema.columns where table_schema='public' and table_name='campaigns' and column_name='payload') as campaigns_payload,
  exists(select 1 from information_schema.columns where table_schema='public' and table_name='campaigns' and column_name='created_by') as campaigns_created_by,
  exists(select 1 from information_schema.columns where table_schema='public' and table_name='audiences' and column_name='campaign_id') as audience_campaign,
  exists(select 1 from information_schema.tables where table_schema='public' and table_name='performance_observations') as performance_table,
  exists(select 1 from information_schema.routines where routine_schema='public' and routine_name='bootstrap_workspace') as bootstrap_rpc;
