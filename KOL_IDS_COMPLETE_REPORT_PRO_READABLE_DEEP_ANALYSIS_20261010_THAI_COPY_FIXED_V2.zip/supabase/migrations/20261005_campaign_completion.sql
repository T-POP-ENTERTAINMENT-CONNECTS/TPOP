-- KOL IDS™ · Campaign completion
-- Marks one authenticated member's campaign as COMPLETE from Step 07.
-- Uses SECURITY DEFINER so a permitted member cannot be blocked by a
-- client-side RLS no-op; the function still enforces membership and
-- an active subscription before changing any data.

create or replace function public.complete_campaign(p_campaign_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid uuid := (select auth.uid());
  v_org_id uuid;
  v_campaign public.campaigns;
begin
  if v_uid is null then
    raise exception 'Authentication required';
  end if;

  select m.organization_id
    into v_org_id
  from public.organization_memberships m
  where m.user_id = v_uid
    and m.status = 'active'
  order by m.created_at asc
  limit 1;

  if v_org_id is null then
    raise exception 'Active organization membership required';
  end if;

  if not public.has_active_subscription(v_org_id) then
    raise exception 'Active subscription required';
  end if;

  select *
    into v_campaign
  from public.campaigns
  where id = p_campaign_id
    and organization_id = v_org_id
  for update;

  if v_campaign.id is null then
    raise exception 'Campaign not found';
  end if;

  update public.campaigns
  set status = 'complete',
      updated_at = now()
  where id = v_campaign.id
    and organization_id = v_org_id;

  return jsonb_build_object(
    'ok', true,
    'campaign_id', v_campaign.id,
    'status', 'complete',
    'completed_at', now()
  );
end;
$$;

revoke all on function public.complete_campaign(uuid) from public, anon;
grant execute on function public.complete_campaign(uuid) to authenticated;
