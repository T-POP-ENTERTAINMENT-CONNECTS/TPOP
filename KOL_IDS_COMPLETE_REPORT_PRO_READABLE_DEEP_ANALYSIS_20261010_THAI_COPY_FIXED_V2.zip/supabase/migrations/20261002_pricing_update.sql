-- KOL IDS pricing update
-- Paid plans:
-- 3 months  = THB 29,900
-- 6 months  = THB 55,900
-- 12 months = THB 105,900
insert into public.plans(code,name,duration_days,price_thb,seats,is_trial)
values
  ('PLAN_3M','3 Months',90,29900,1,false),
  ('PLAN_6M','6 Months',180,55900,2,false),
  ('PLAN_12M','12 Months',365,105900,3,false)
on conflict (code) do update set
  name=excluded.name,
  duration_days=excluded.duration_days,
  price_thb=excluded.price_thb,
  seats=excluded.seats,
  is_trial=excluded.is_trial,
  updated_at=now();
